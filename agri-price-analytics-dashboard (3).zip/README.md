# GreenLink Karnataka

A Karnataka agri price and direct-trade dashboard: live mandi snapshots, farmer offers and buyer bids, price
calculator, trade analytics, sustainability impact and a trade simulator. Built with React, Vite and Tailwind CSS.

Demo login: **demo@greenlink.in** / **greenlink123** (or press “Explore with demo credentials”).

---

## ⚠️ Opening the downloaded folder

**Do not double-click the top-level `index.html` in this source folder.** It is the Vite entry file: it needs the dev
server or a build, so it shows a plain helper page (previously a blank page) when opened directly. This is the usual
reason an extracted ZIP “does not work”.

There are two supported ways to open the site:

### Option 1 — Ready-to-open website (recommended, no install)

**Double-click `OPEN-THIS-GreenLink-Karnataka.html`** in the project root. It is the complete website in a single
self-contained file (styles, scripts and the farm photo are all inlined), so it works offline with no server and no
`npm install`. `dist/index.html` is an identical copy.

You can also get the same file from inside the running app: **“Download offline copy” → “Download index.html”**
(no unzip needed) or **“Download website ZIP”** (includes `index.html` + `README.txt`).

### Option 2 — Run the source with Node.js

```bash
npm install
npm run dev      # development server, usually http://localhost:5173
```

```bash
npm run build    # writes a self-contained dist/index.html
npm run preview  # preview the production build
```

Requires Node.js 18 or newer.

---

## What is in this project

| Path | Purpose |
| --- | --- |
| `src/App.tsx` | Auth + theme shell |
| `src/components/LoginPage.tsx` | First screen: sign in, sign up, reset password |
| `src/components/Dashboard.tsx` | Dashboard layout |
| `src/components/OfflineHelp.tsx` | In-app “open offline / download” help |
| `src/lib/offline.ts` | Browser-side single-file HTML and ZIP downloads |
| `src/lib/data.ts` | Karnataka crops, mandis, demo lots and market maths |
| `src/index.css` | Design tokens, dark/light themes, shared component styles |
| `dist/index.html` | Production build — one self-contained file |
| `OPEN-THIS-GreenLink-Karnataka.html` | Ready-to-open standalone copy (double-click this) |
| `HOW-TO-OPEN.txt` | Plain-English opening instructions for recipients |

## Delivery checklist (if you are sharing a ZIP)

- Zip the **ready-to-open file**: include `OPEN-THIS-GreenLink-Karnataka.html` (and `HOW-TO-OPEN.txt`), or the built
  `dist/index.html`. Recipients just extract and double-click it.
- Or zip the whole project **without** `node_modules`, and tell recipients to run `npm install && npm run build`, then
  open `dist/index.html`.
- Never ask a non-technical recipient to double-click the top-level source `index.html` — it requires the build step.

## Notes

- All prices, bids and impact metrics are simulated around typical Karnataka mandi ranges (INR/quintal).
- Web fonts load from Google Fonts when online; the app automatically falls back to system fonts offline.
- Theme choice is stored in the browser. “Keep me signed in” is optional.
