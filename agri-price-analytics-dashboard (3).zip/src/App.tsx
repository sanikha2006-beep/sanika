import { useEffect, useState } from "react";
import LoginPage, { type Session } from "./components/LoginPage";
import Dashboard from "./components/Dashboard";

const SESSION_KEY = "greenlink.session";
const THEME_KEY = "greenlink.theme";

type Theme = "dark" | "light";

function readStoredSession(): Session | null {
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Session>;
    if (!parsed || typeof parsed.email !== "string" || !parsed.role || !parsed.remember) return null;
    return {
      name: typeof parsed.name === "string" ? parsed.name : "GreenLink member",
      email: parsed.email,
      role: parsed.role,
      org: typeof parsed.org === "string" ? parsed.org : "Karnataka",
      remember: true,
    };
  } catch {
    return null;
  }
}

function readStoredTheme(): Theme {
  try {
    const stored = window.localStorage.getItem(THEME_KEY);
    if (stored === "light" || stored === "dark") return stored;
  } catch {
    /* ignore */
  }
  return "dark";
}

export default function App() {
  const [session, setSession] = useState<Session | null>(() => readStoredSession());
  const [theme, setTheme] = useState<Theme>(() => readStoredTheme());
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.style.colorScheme = theme;
    try {
      window.localStorage.setItem(THEME_KEY, theme);
    } catch {
      /* ignore */
    }
  }, [theme]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
    try {
      if (session?.remember) {
        window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
      } else {
        window.localStorage.removeItem(SESSION_KEY);
      }
    } catch {
      /* ignore */
    }
    if (session) setNotice("");
  }, [session]);

  function handleLogin(next: Session) {
    setSession(next);
  }

  function handleLogout() {
    setSession(null);
    setNotice("You've been signed out safely. Sign in again to return to your trade desk.");
    try {
      window.localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
  }

  const toggleTheme = () => setTheme((current) => (current === "dark" ? "light" : "dark"));

  if (!session) {
    return (
      <LoginPage
        onLogin={handleLogin}
        theme={theme}
        onToggleTheme={toggleTheme}
        notice={notice}
      />
    );
  }

  return (
    <Dashboard
      session={session}
      theme={theme}
      onToggleTheme={toggleTheme}
      onLogout={handleLogout}
    />
  );
}
