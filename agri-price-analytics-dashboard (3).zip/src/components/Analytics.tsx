import { useMemo, useState } from "react";
import { Activity, BarChart3, TrendingUp } from "lucide-react";
import {
  COMMODITIES,
  fmtINR,
  fmtNumber,
  fmtTonnes,
  getCommodity,
  seededRandom,
  type BuyerBid,
  type FarmerOffer,
} from "../lib/data";
import { SectionHead } from "./ui";

export default function Analytics({
  offers,
  bids,
  tick,
}: {
  offers: FarmerOffer[];
  bids: BuyerBid[];
  tick: number;
}) {
  const [commodityId, setCommodityId] = useState("all");

  const relevantOffers = useMemo(
    () => offers.filter((o) => commodityId === "all" || o.commodityId === commodityId),
    [offers, commodityId]
  );
  const relevantBids = useMemo(
    () => bids.filter((b) => commodityId === "all" || b.commodityId === commodityId),
    [bids, commodityId]
  );

  const stats = useMemo(() => {
    const prices = [...relevantOffers.map((o) => o.price), ...relevantBids.map((b) => b.price)];
    const minPrice = prices.length ? Math.min(...prices) : 0;
    const maxPrice = prices.length ? Math.max(...prices) : 0;
    const volume = [...relevantOffers, ...relevantBids].reduce((sum, lot) => sum + lot.quantity, 0);
    const avgAsk = relevantOffers.length
      ? relevantOffers.reduce((s, o) => s + o.price, 0) / relevantOffers.length
      : 0;
    const avgBid = relevantBids.length
      ? relevantBids.reduce((s, b) => s + b.price, 0) / relevantBids.length
      : 0;
    const baseline = commodityId === "all" ? 3500 : getCommodity(commodityId)?.baseline ?? 3500;
    const spreadPct = avgAsk ? ((avgBid - avgAsk) / avgAsk) * 100 : 0;
    const farmerShare = Math.max(56, Math.min(84, 64 + spreadPct * 1.4));
    const middlemenSavings = Math.max(12, Math.min(42, 16 + spreadPct * 2.1));
    const mid = Math.round((minPrice + maxPrice) / 2);
    return { minPrice, maxPrice, volume, avgAsk, avgBid, baseline, farmerShare, middlemenSavings, mid, lots: relevantOffers.length + relevantBids.length };
  }, [relevantOffers, relevantBids, commodityId]);

  const sparkBars = useMemo(() => {
    const offset = commodityId === "all" ? 3 : COMMODITIES.findIndex((c) => c.id === commodityId) + 7;
    return Array.from({ length: 20 }, (_, i) => {
      const base = 32 + seededRandom(i + offset * 3.1 + tick * 0.9) * 58;
      const trend = Math.sin((i / 19) * Math.PI * 1.4) * 8;
      return Math.max(14, Math.min(98, base + trend));
    });
  }, [commodityId, tick]);

  const volumeBars = useMemo(() => {
    const seedBase = commodityId === "all" ? 11 : COMMODITIES.findIndex((c) => c.id === commodityId) * 5 + 21;
    return Array.from({ length: 10 }, (_, i) => Math.round(22 + seededRandom(seedBase + i * 1.7 + tick * 0.4) * 66));
  }, [commodityId, tick]);

  return (
    <div id="analytics" className="surface p-4 sm:p-5">
      <SectionHead
        icon={<BarChart3 size={14} />}
        title="Price & volume analytics"
        subtitle="Monitor volatility, depth and farmer share across Karnataka crops."
        actions={
          <select
            value={commodityId}
            onChange={(e) => setCommodityId(e.target.value)}
            className="field w-[134px] py-1.5 text-[11px]"
            aria-label="Analytics commodity"
          >
            <option value="all">All commodities</option>
            {COMMODITIES.map((c) => (
              <option key={c.id} value={c.id}>{c.short}</option>
            ))}
          </select>
        }
        compact
      />

      <div className="mt-3.5 grid grid-cols-2 gap-2.5">
        <div className="surface-soft flex flex-col gap-2 p-3">
          <div className="flex items-start justify-between gap-1">
            <span className="text-[10px]" style={{ color: "var(--faint)" }}>24h price range</span>
            <Activity size={11} style={{ color: "var(--accent)" }} />
          </div>
          <span className="font-mono text-[10.5px] font-medium leading-tight">
            {fmtINR(stats.minPrice)} – {fmtINR(stats.maxPrice)}
            <span className="block text-[8.5px] font-normal" style={{ color: "var(--faint)" }}>per quintal</span>
          </span>
          <div className="flex h-16 items-end gap-[3px]" role="img" aria-label="Simulated 24 hour price movement">
            {sparkBars.map((height, i) => (
              <div
                key={`${i}-${height}`}
                className="bar-grow flex-1 rounded-t-[2px] transition-all duration-500"
                style={{
                  height: `${height}%`,
                  background: i === sparkBars.length - 1
                    ? "var(--lime)"
                    : `linear-gradient(180deg, var(--accent) 0%, ${i % 3 === 0 ? "var(--lime)" : "var(--accent)"} 100%)`,
                  opacity: 0.45 + (i / sparkBars.length) * 0.55,
                  animationDelay: `${i * 18}ms`,
                }}
                title={`${fmtINR(stats.minPrice + (stats.maxPrice - stats.minPrice) * (height / 100))} / quintal`}
              />
            ))}
          </div>
        </div>

        <div className="surface-soft flex flex-col gap-2 p-3">
          <div className="flex items-start justify-between gap-1">
            <span className="text-[10px]" style={{ color: "var(--faint)" }}>Today&apos;s volume</span>
            <TrendingUp size={11} style={{ color: "var(--sky)" }} />
          </div>
          <span className="font-mono text-[10.5px] font-medium leading-tight">
            {fmtTonnes(stats.volume)}
            <span className="block text-[8.5px] font-normal" style={{ color: "var(--faint)" }}>{stats.lots} open lots</span>
          </span>
          <div className="flex h-16 items-end gap-1" role="img" aria-label="Simulated volume by arrival window">
            {volumeBars.map((height, i) => (
              <div
                key={`${i}-${height}`}
                className="bar-grow flex-1 rounded-t-[2px]"
                style={{
                  height: `${height}%`,
                  background: "linear-gradient(180deg, var(--sky), var(--accent))",
                  opacity: 0.5 + (i / volumeBars.length) * 0.5,
                  animationDelay: `${i * 30}ms`,
                }}
                title={`${fmtNumber(stats.volume / 10, 1)} t arrival window`}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-[10.5px]" style={{ color: "var(--muted)" }}>Farmer share of consumer rupee</span>
            <span className="font-mono text-[11px] font-semibold" style={{ color: "var(--accent)" }}>{stats.farmerShare.toFixed(0)}%</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--panel-3)" }}>
            <div className="h-full rounded-full transition-all duration-700" style={{ width: `${stats.farmerShare}%`, background: "linear-gradient(90deg, var(--accent), var(--lime))" }} />
          </div>
          <span className="text-[9px]" style={{ color: "var(--faint)" }}>Direct sales keep more value at the farmgate.</span>
        </div>
        <div className="flex flex-col gap-1.5">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-[10.5px]" style={{ color: "var(--muted)" }}>Direct vs. middlemen savings</span>
            <span className="font-mono text-[11px] font-semibold" style={{ color: "var(--accent)" }}>{stats.middlemenSavings.toFixed(0)}%</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--panel-3)" }}>
            <div className="h-full rounded-full transition-all duration-700" style={{ width: `${stats.middlemenSavings}%`, background: "linear-gradient(90deg, var(--sky), var(--accent))" }} />
          </div>
          <span className="text-[9px]" style={{ color: "var(--faint)" }}>Estimated commission and handling avoided.</span>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between rounded-lg border px-2.5 py-2 text-[9.5px]" style={{ borderColor: "var(--line)", background: "var(--panel-2)", color: "var(--faint)" }}>
        <span>Indicative mid · {fmtINR(stats.mid)}/qtl</span>
        <span className="inline-flex items-center gap-1 font-mono">
          <span className="h-1 w-1 rounded-full" style={{ background: "var(--accent)" }} /> live sample
        </span>
      </div>
    </div>
  );
}
