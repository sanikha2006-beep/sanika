import { useState } from "react";
import { CalendarDays, Download, Leaf, Sparkles } from "lucide-react";
import { useMarket } from "../lib/useMarket";
import { fmtTonnes, getCommodity, getRegion } from "../lib/data";
import type { Session } from "./LoginPage";
import Header from "./Header";
import HeroOverview from "./HeroOverview";
import PriceCalculator from "./PriceCalculator";
import PriceTicker from "./PriceTicker";
import OrderBook from "./OrderBook";
import Analytics from "./Analytics";
import Sustainability from "./Sustainability";
import TradeSimulator from "./TradeSimulator";
import OfflineHelp from "./OfflineHelp";
import { Logo } from "./ui";

const ROLE_COPY: Record<Session["role"], string> = {
  farmer: "Your lots, mandi benchmarks and buyer interest for today.",
  fpo: "Your collective's prices, institutional bids and logistics impact for today.",
  buyer: "Today's Karnataka supply, price depth and direct sourcing opportunities.",
};

export default function Dashboard({
  session,
  theme,
  onToggleTheme,
  onLogout,
}: {
  session: Session;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  onLogout: () => void;
}) {
  const market = useMarket();
  const [commodityFilter, setCommodityFilter] = useState("all");

  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
  const firstName = session.name.split(" ")[0];

  function exportData() {
    const rows: string[][] = [
      ["Type", "Commodity", "District / Mandi", "Price (INR/quintal)", "Quantity (t)", "Detail"],
    ];
    market.offers.forEach((offer) => {
      rows.push([
        "Farmer offer",
        getCommodity(offer.commodityId)?.name ?? offer.commodityId,
        getRegion(offer.regionId)?.label ?? offer.regionId,
        String(offer.price),
        String(offer.quantity),
        offer.practice,
      ]);
    });
    market.bids.forEach((bid) => {
      rows.push([
        "Buyer bid",
        getCommodity(bid.commodityId)?.name ?? bid.commodityId,
        getRegion(bid.regionId)?.label ?? bid.regionId,
        String(bid.price),
        String(bid.quantity),
        bid.contract,
      ]);
    });
    const csv = rows.map((row) => row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `greenlink-karnataka-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div id="dashboard" className="min-h-screen" style={{ background: "var(--bg)" }}>
      <Header
        session={session}
        theme={theme}
        onToggleTheme={onToggleTheme}
        onLogout={onLogout}
        live={market.autoRefresh}
        lastUpdated={market.lastUpdated}
        autoRefresh={market.autoRefresh}
        onToggleAutoRefresh={market.setAutoRefresh}
        onRefresh={market.refresh}
      />

      <main className="mx-auto w-full max-w-[1240px] px-4 py-5 sm:px-6 sm:py-6">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.14em]" style={{ color: "var(--accent)" }}>
              <Sparkles size={11} /> {session.role === "buyer" ? "Procurement desk" : session.role === "fpo" ? "FPO trading desk" : "Farmer workspace"}
            </div>
            <h1 className="mt-1 font-display text-[20px] font-semibold tracking-tight sm:text-[23px]">
              Namaskara, {firstName}.
            </h1>
            <p className="mt-1 max-w-xl text-[11px] leading-relaxed" style={{ color: "var(--muted)" }}>
              {ROLE_COPY[session.role]}
            </p>
            <p className="mt-1 text-[10px] sm:hidden" style={{ color: "var(--faint)" }}>
              {today} · {market.offers.length} active lots
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[10.5px]" style={{ borderColor: "var(--line)", background: "var(--panel)", color: "var(--muted)" }}>
              <CalendarDays size={12} style={{ color: "var(--accent)" }} /> {today}
            </span>
            <span className="hidden items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[10.5px] lg:inline-flex" style={{ borderColor: "var(--line)", background: "var(--panel)", color: "var(--muted)" }}>
              <Leaf size={12} style={{ color: "var(--accent)" }} /> {fmtTonnes(market.totals.totalVolume)} open volume
            </span>
            <button type="button" onClick={exportData} className="btn-ghost text-[10.5px]">
              <Download size={12} /> Export book
            </button>
          </div>
        </div>

        <div className="space-y-4 sm:space-y-4">
          <PriceCalculator offers={market.offers} bids={market.bids} />

          <section className="grid items-stretch gap-4 xl:grid-cols-[1.35fr_1fr]">
            <HeroOverview offers={market.offers} bids={market.bids} totals={market.totals} live={market.autoRefresh} />
            <PriceTicker
              offers={market.offers}
              bids={market.bids}
              filter={commodityFilter}
              onFilterChange={setCommodityFilter}
              autoRefresh={market.autoRefresh}
              onToggleAutoRefresh={market.setAutoRefresh}
              onRefresh={market.refresh}
              lastUpdated={market.lastUpdated}
            />
          </section>

          <section className="grid items-stretch gap-4 xl:grid-cols-[1.42fr_1fr]">
            <OrderBook
              offers={market.offers}
              bids={market.bids}
              commodityFilter={commodityFilter}
              onCommodityFilterChange={setCommodityFilter}
            />
            <div className="flex flex-col gap-4">
              <Analytics offers={market.offers} bids={market.bids} tick={market.tick} />
              <Sustainability offers={market.offers} bids={market.bids} tick={market.tick} />
            </div>
          </section>

          <TradeSimulator
            offers={market.offers}
            bids={market.bids}
            onAddOffer={market.addOffer}
            onAddBid={market.addBid}
            onReset={market.reset}
          />

          <footer className="mt-2 border-t pt-4" style={{ borderColor: "var(--line)" }}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div className="flex items-start gap-2.5">
                <Logo size="sm" />
                <p className="max-w-md text-[10px] leading-relaxed" style={{ color: "var(--faint)" }}>
                  A Karnataka-focused concept workspace for a sustainable, real-time farmer–buyer exchange. Prices are
                  simulated around typical Karnataka mandi ranges. Connect AGMARKNET or state APIs to go live.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[10px]">
                {["Data sources", "Fair-trade code", "Privacy", "Support"].map((item) => (
                  <a key={item} href={`#${item.toLowerCase().replace(/\s+/g, "-")}`} style={{ color: "var(--muted)" }} className="hover:underline">
                    {item}
                  </a>
                ))}
                <OfflineHelp label="Offline copy" />
                <span style={{ color: "var(--faint)" }}>© 2026 GreenLink Karnataka</span>
              </div>
            </div>
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 border-t pt-2.5 text-[9.5px]" style={{ borderColor: "var(--line)", color: "var(--faint)" }}>
              <span>Signed in as {session.email} · {session.org}</span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} />
                Concept dashboard · all trades simulated
              </span>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
}
