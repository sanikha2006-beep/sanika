import { useEffect, useRef, useState } from "react";
import { Bell, ChevronDown, LogOut, Menu, RefreshCw, UserRound, X } from "lucide-react";
import { cn } from "../utils/cn";
import type { Session } from "./LoginPage";
import { fmtTime } from "../lib/data";
import OfflineHelp from "./OfflineHelp";
import { LiveBadge, Logo, ThemeToggle } from "./ui";

const NAV = [
  { href: "#dashboard", label: "Dashboard" },
  { href: "#market", label: "Live Market" },
  { href: "#analytics", label: "Trade Analytics" },
  { href: "#sustainability", label: "Sustainability" },
];

const ROLE_LABEL: Record<Session["role"], string> = {
  farmer: "Farmer",
  fpo: "FPO lead",
  buyer: "Institutional buyer",
};

export default function Header({
  session,
  theme,
  onToggleTheme,
  onLogout,
  live,
  lastUpdated,
  autoRefresh,
  onToggleAutoRefresh,
  onRefresh,
}: {
  session: Session;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  onLogout: () => void;
  live: boolean;
  lastUpdated: Date;
  autoRefresh: boolean;
  onToggleAutoRefresh: (value: boolean) => void;
  onRefresh: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const userRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserOpen(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const initials = session.name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <header
      className="sticky top-0 z-30 border-b backdrop-blur-xl"
      style={{
        borderColor: "var(--line)",
        background: "color-mix(in srgb, var(--panel) 86%, transparent)",
        boxShadow: "0 1px 0 rgba(10,30,20,0.02)",
      }}
    >
      <div className="mx-auto flex h-16 w-full max-w-[1240px] items-center justify-between gap-4 px-4 sm:px-6">
        <div className="flex min-w-0 items-center gap-4">
          <a href="#dashboard" aria-label="GreenLink Karnataka home" className="shrink-0">
            <Logo />
          </a>
          <span className="hidden h-7 w-px lg:block" style={{ background: "var(--line)" }} />
          <nav className="hidden items-center gap-0.5 lg:flex" aria-label="Primary">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="rounded-lg px-3 py-2 text-[12px] font-medium transition hover:bg-[var(--panel-2)] hover:text-[var(--accent)]"
                style={{ color: "var(--muted)" }}
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden xl:block">
            <LiveBadge live={live} />
          </div>

          <div className="hidden items-center gap-1.5 rounded-lg border px-2 py-1.5 md:flex" style={{ borderColor: "var(--line)", background: "var(--panel-2)" }}>
            <button
              type="button"
              onClick={onRefresh}
              title="Refresh prices now"
              className="rounded p-0.5 transition hover:opacity-70"
              style={{ color: "var(--accent)" }}
            >
              <RefreshCw size={12.5} />
            </button>
            <span className="font-mono text-[10px]" style={{ color: "var(--faint)" }}>
              {autoRefresh ? "AUTO" : "MANUAL"} · {fmtTime(lastUpdated)}
            </span>
            <label className="ml-1 flex cursor-pointer items-center gap-1" title="Toggle auto-refresh">
              <input
                type="checkbox"
                checked={autoRefresh}
                onChange={(e) => onToggleAutoRefresh(e.target.checked)}
                className="h-3 w-3 rounded"
              />
            </label>
          </div>

          <div className="hidden sm:block">
            <OfflineHelp variant="icon" />
          </div>

          <ThemeToggle theme={theme} onToggle={onToggleTheme} />

          <div className="relative" ref={notifRef}>
            <button
              type="button"
              aria-label="Notifications"
              onClick={() => {
                setNotifOpen((v) => !v);
                setUserOpen(false);
              }}
              className="relative flex h-9 w-9 items-center justify-center rounded-full border transition hover:brightness-105"
              style={{ borderColor: "var(--line-strong)", background: "var(--panel-2)", color: "var(--muted)" }}
            >
              <Bell size={15} />
              <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} />
            </button>
            {notifOpen && (
              <div
                className="absolute right-0 top-11 w-[270px] animate-rise overflow-hidden rounded-xl border shadow-xl"
                style={{ borderColor: "var(--line)", background: "var(--panel)", boxShadow: "var(--shadow-lift)" }}
              >
                <div className="border-b px-3.5 py-2.5" style={{ borderColor: "var(--line)" }}>
                  <p className="font-display text-[12px] font-semibold">Market alerts</p>
                  <p className="text-[10px]" style={{ color: "var(--faint)" }}>Simulated for this workspace</p>
                </div>
                {[
                  "Tur crossed its MSP reference in Raichur APMC.",
                  "New institutional bid for Ragi from Bengaluru Foodworks.",
                  "3 FPO lots now within 40 km of your delivery hub.",
                ].map((alert, i) => (
                  <div key={alert} className={cn("px-3.5 py-2.5 text-[11px] leading-relaxed", i > 0 && "border-t")} style={{ borderColor: "var(--line)", color: "var(--muted)" }}>
                    <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full align-middle" style={{ background: "var(--accent)" }} />
                    {alert}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="relative" ref={userRef}>
            <button
              type="button"
              onClick={() => {
                setUserOpen((v) => !v);
                setNotifOpen(false);
              }}
              aria-expanded={userOpen}
              className="flex items-center gap-2 rounded-full border py-1 pl-1 pr-1.5 transition sm:pr-2.5"
              style={{ borderColor: "var(--line-strong)", background: "var(--panel-2)" }}
            >
              <span
                className="flex h-7 w-7 items-center justify-center rounded-full text-[10.5px] font-bold"
                style={{ background: "var(--accent-soft)", color: "var(--accent)", border: "1px solid var(--accent-line)" }}
              >
                {initials || <UserRound size={13} />}
              </span>
              <span className="hidden text-left sm:block">
                <span className="block max-w-[110px] truncate text-[11px] font-semibold leading-tight">{session.name}</span>
                <span className="block text-[9.5px] leading-tight" style={{ color: "var(--faint)" }}>
                  {ROLE_LABEL[session.role]}
                </span>
              </span>
              <ChevronDown size={12} className="hidden sm:block" style={{ color: "var(--faint)" }} />
            </button>
            {userOpen && (
              <div
                className="absolute right-0 top-11 w-[250px] animate-rise overflow-hidden rounded-xl border shadow-xl"
                style={{ borderColor: "var(--line)", background: "var(--panel)", boxShadow: "var(--shadow-lift)" }}
              >
                <div className="px-3.5 py-3" style={{ borderBottom: "1px solid var(--line)" }}>
                  <p className="truncate text-[12px] font-semibold">{session.name}</p>
                  <p className="truncate text-[10.5px]" style={{ color: "var(--faint)" }}>{session.email}</p>
                  <div className="mt-2 flex max-w-full items-center gap-1.5 truncate rounded-full px-2 py-0.5 text-[9.5px] font-medium" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                    <span className="h-1 w-1 shrink-0 rounded-full" style={{ background: "var(--accent)" }} />
                    <span className="truncate">{ROLE_LABEL[session.role]} · {session.org}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setUserOpen(false);
                    onRefresh();
                  }}
                  className="flex w-full items-center gap-2 px-3.5 py-2.5 text-left text-[11.5px] transition hover:bg-[var(--panel-2)]"
                  style={{ color: "var(--muted)" }}
                >
                  <RefreshCw size={13} /> Sync market data
                </button>
                <button
                  type="button"
                  onClick={onLogout}
                  className="flex w-full items-center gap-2 border-t px-3.5 py-2.5 text-left text-[11.5px] transition hover:bg-[var(--panel-2)]"
                  style={{ borderColor: "var(--line)", color: "#e2694f" }}
                >
                  <LogOut size={13} /> Sign out
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
            className="flex h-9 w-9 items-center justify-center rounded-full border lg:hidden"
            style={{ borderColor: "var(--line-strong)", background: "var(--panel-2)", color: "var(--muted)" }}
          >
            {menuOpen ? <X size={16} /> : <Menu size={16} />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="animate-rise border-t px-4 py-3 lg:hidden" style={{ borderColor: "var(--line)", background: "var(--panel)" }}>
          <nav className="grid gap-1" aria-label="Mobile">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMenuOpen(false)}
                className="rounded-lg px-3 py-2.5 text-[12.5px] font-medium"
                style={{ color: "var(--muted)" }}
              >
                {item.label}
              </a>
            ))}
          </nav>
          <div className="mt-2 flex items-center justify-between gap-2 border-t pt-3" style={{ borderColor: "var(--line)" }}>
            <LiveBadge live={live} />
            <button type="button" onClick={onRefresh} className="btn-ghost">
              <RefreshCw size={13} /> Refresh
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
