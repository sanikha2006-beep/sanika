import { ArrowUpRight, Building2, Coins, Leaf, MapPin, Sprout, TrendingUp } from "lucide-react";
import { fmtTonnes } from "../lib/data";
import type { BuyerBid, FarmerOffer } from "../lib/data";
import { LiveBadge } from "./ui";

const FEATURES = [
  "MSP-aware pricing",
  "Mandi-linked benchmarks",
  "FPO aggregation",
  "Impact analytics",
];

export default function HeroOverview({
  offers,
  bids,
  totals,
  live = true,
}: {
  offers: FarmerOffer[];
  bids: BuyerBid[];
  totals: { totalVolume: number; carbonSaved: number; ordersChange: number };
  live?: boolean;
}) {
  const metrics = [
    {
      label: "Active farmer lots",
      value: String(offers.length),
      icon: Sprout,
      note: "Verified across 9 Karnataka mandis",
      accent: "var(--accent)",
    },
    {
      label: "Institutional buy orders",
      value: String(bids.length),
      icon: Building2,
      note: `+${totals.ordersChange.toFixed(1)}% vs 30-day average`,
      accent: "var(--sky)",
    },
    {
      label: "Carbon saved",
      value: `${totals.carbonSaved.toFixed(1)} t`,
      icon: Leaf,
      note: "vs. conventional mandi logistics",
      accent: "var(--lime)",
    },
  ];

  return (
    <div className="surface relative isolate overflow-hidden p-5 sm:p-6">
      <div
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(ellipse at 96% 0%, var(--accent-soft), transparent 52%), radial-gradient(ellipse at 0% 100%, rgba(182,227,124,0.07), transparent 45%)",
        }}
      />
      <div className="grain pointer-events-none absolute inset-0 -z-10 opacity-[0.22]" />

      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="inline-flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.15em]" style={{ color: "var(--accent)" }}>
          <span className="h-px w-5" style={{ background: "var(--accent)" }} /> State of the market
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px]" style={{ borderColor: "var(--line)", color: "var(--muted)", background: "var(--panel-2)" }}>
          <MapPin size={11} style={{ color: "var(--accent)" }} /> Karnataka · 9 APMC mandis
        </span>
      </div>

      <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-xl">
          <h2 className="font-display text-[23px] font-semibold leading-[1.15] tracking-tight sm:text-[27px]">
            Karnataka sustainable
            <br className="hidden sm:block" />{" "}
            <span style={{ color: "var(--accent)" }}>trade bridge.</span>
          </h2>
          <p className="mt-3 max-w-lg text-[12px] leading-relaxed" style={{ color: "var(--muted)" }}>
            Track real-time prices and trade opportunities connecting Karnataka&apos;s farmers and FPOs with institutional
            buyers. Transparent, INR-denominated discovery across the state&apos;s major crops and mandis.
          </p>
        </div>
        <div className="hidden shrink-0 sm:block">
          <LiveBadge live={live} />
          <div className="mt-2 flex items-center justify-end gap-1.5 text-[10px]" style={{ color: "var(--faint)" }}>
            <TrendingUp size={11} /> {fmtTonnes(totals.totalVolume)} in open lots
          </div>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <div
              key={metric.label}
              className="rounded-xl border p-3 transition hover:brightness-[1.02]"
              style={{ borderColor: "var(--line)", background: "var(--panel)" }}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-medium uppercase tracking-[0.06em]" style={{ color: "var(--faint)" }}>
                  {metric.label}
                </span>
                <Icon size={13} style={{ color: metric.accent }} />
              </div>
              <div className="mt-1.5 font-display text-[21px] font-semibold leading-none tracking-tight tabular">{metric.value}</div>
              <div className="mt-1.5 flex items-start gap-1 text-[9.5px] leading-snug" style={{ color: "var(--muted)" }}>
                <span className="mt-1 h-1 w-1 shrink-0 rounded-full" style={{ background: metric.accent }} />
                {metric.note}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-1.5">
        {FEATURES.map((feature) => (
          <span
            key={feature}
            className="rounded-full border px-2 py-1 text-[9.5px] font-medium"
            style={{ borderColor: "var(--line)", color: "var(--muted)", background: "var(--panel-2)" }}
          >
            {feature}
          </span>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t pt-3.5" style={{ borderColor: "var(--line)" }}>
        <div className="flex items-center gap-3">
          <a href="#market" className="btn-primary px-3 py-2 text-[11px]">
            Explore live market <ArrowUpRight size={13} />
          </a>
          <a href="#simulate" className="text-[11px] font-medium hover:underline" style={{ color: "var(--muted)" }}>
            Simulate a trade
          </a>
        </div>
        <span className="flex items-center gap-1.5 text-[9.5px]" style={{ color: "var(--faint)" }}>
          <Coins size={11} /> Indicative · INR per quintal
        </span>
      </div>
    </div>
  );
}
