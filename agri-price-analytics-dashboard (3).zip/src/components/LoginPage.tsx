import { useMemo, useState, type FormEvent } from "react";
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  Eye,
  EyeOff,
  Leaf,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
  Sprout,
  TrendingUp,
  UsersRound,
} from "lucide-react";
import { cn } from "../utils/cn";
import { COMMODITIES, fmtINR } from "../lib/data";
import heroImage from "../assets/karnataka-fields.jpg";
import { Logo, ThemeToggle } from "./ui";
import OfflineHelp from "./OfflineHelp";

export type Role = "farmer" | "fpo" | "buyer";

export interface Session {
  name: string;
  email: string;
  role: Role;
  org: string;
  remember?: boolean;
}

const ROLES: { id: Role; label: string; meta: string; icon: typeof Sprout; persona: string; org: string }[] = [
  { id: "farmer", label: "Farmer", meta: "Sell produce", icon: Sprout, persona: "Aruna Hegde", org: "Mandya · 4.2 acres" },
  { id: "fpo", label: "FPO", meta: "Aggregate lots", icon: UsersRound, persona: "Nandini Rao", org: "Kaveri FPO Collective" },
  { id: "buyer", label: "Buyer", meta: "Source direct", icon: Building2, persona: "Rohan Menon", org: "Bengaluru Foodworks" },
];

type Mode = "signin" | "signup" | "reset";

const DEMO_EMAIL = "demo@greenlink.in";
const DEMO_PASSWORD = "greenlink123";

export default function LoginPage({
  onLogin,
  theme,
  onToggleTheme,
  notice,
}: {
  onLogin: (session: Session) => void;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  notice?: string;
}) {
  const [mode, setMode] = useState<Mode>("signin");
  const [role, setRole] = useState<Role>("fpo");
  const [name, setName] = useState("");
  const [email, setEmail] = useState(DEMO_EMAIL);
  const [password, setPassword] = useState(DEMO_PASSWORD);
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const [noticeText, setNoticeText] = useState(notice ?? "");
  const [loading, setLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const activeRole = useMemo(() => ROLES.find((r) => r.id === role) ?? ROLES[0], [role]);

  const snapshotPrices = [
    { commodity: COMMODITIES[0], price: 2284, change: 1.2 },
    { commodity: COMMODITIES[1], price: 3512, change: 0.6 },
    { commodity: COMMODITIES[2], price: 6740, change: -0.4 },
  ];

  function completeLogin(demo = false) {
    const sessionEmail = demo ? DEMO_EMAIL : email.trim();
    const displayName =
      mode === "signup" && name.trim()
        ? name.trim()
        : demo
          ? activeRole.persona
          : email.trim().length > 0 && !email.includes("demo")
            ? email.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())
            : activeRole.persona;

    setLoading(true);
    setError("");
    window.setTimeout(() => {
      setLoading(false);
      onLogin({
        name: displayName || activeRole.persona,
        email: sessionEmail || DEMO_EMAIL,
        role,
        org: activeRole.org,
        remember,
      });
    }, 850);
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setNoticeText("");
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

    if (mode === "reset") {
      if (!emailOk) {
        setError("Enter a valid email address to receive the reset link.");
        return;
      }
      setError("");
      setLoading(true);
      window.setTimeout(() => {
        setLoading(false);
        setResetSent(true);
      }, 700);
      return;
    }

    if (mode === "signup" && name.trim().length < 2) {
      setError("Tell us your name so buyers and farmers know who they're trading with.");
      return;
    }
    if (!emailOk) {
      setError("Enter a valid email address (for example, demo@greenlink.in).");
      return;
    }
    if (password.length < 6) {
      setError("Your password needs at least 6 characters.");
      return;
    }
    completeLogin();
  }

  function switchMode(next: Mode) {
    setMode(next);
    setError("");
    setNoticeText("");
    setResetSent(false);
    if (next === "signup") {
      setEmail("");
      setPassword("");
    }
    if (next === "signin") {
      setEmail(DEMO_EMAIL);
      setPassword(DEMO_PASSWORD);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.06fr_0.94fr]" style={{ background: "var(--bg)" }}>
      {/* ---------------- Visual panel ---------------- */}
      <aside className="relative overflow-hidden lg:min-h-screen">
        <img
          src={heroImage}
          alt="Terraced farmland and coconut palms across rural Karnataka at golden hour"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(175deg, rgba(3,17,10,0.92) 0%, rgba(4,24,14,0.7) 38%, rgba(3,17,10,0.82) 70%, rgba(2,12,7,0.96) 100%)",
          }}
        />
        <div
          className="absolute inset-0 opacity-60"
          style={{
            background:
              "radial-gradient(ellipse at 78% 18%, rgba(84,229,173,0.24), transparent 55%), radial-gradient(ellipse at 5% 92%, rgba(182,227,124,0.16), transparent 50%)",
          }}
        />

        <div className="relative z-10 flex h-full flex-col justify-between gap-10 p-7 sm:p-10 lg:p-12 xl:p-14">
          <div className="flex items-center justify-between gap-4">
            <Logo size="lg" inverted />
            <span
              className="hidden items-center gap-1.5 rounded-full border px-3 py-1 text-[10px] font-medium uppercase tracking-[0.14em] sm:inline-flex"
              style={{ borderColor: "rgba(233,247,238,0.24)", color: "rgba(233,247,238,0.82)", background: "rgba(6,28,17,0.32)" }}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-[#7ce0a8]" />
              Karnataka agri network
            </span>
          </div>

          <div className="max-w-xl animate-rise">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.07] px-3 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.16em] text-white/85 backdrop-blur">
              <Leaf size={12} className="text-[#a7e88a]" />
              Direct trade · Fair prices · Low carbon
            </div>
            <h1 className="font-display text-[2.1rem] font-semibold leading-[1.08] tracking-tight text-white sm:text-[2.85rem] xl:text-[3.25rem]">
              From Karnataka&apos;s soil to the markets
              <span className="block text-[#a7e88a]">that value it.</span>
            </h1>
            <p className="mt-4 max-w-md text-[13.5px] leading-relaxed text-white/75">
              One workspace for mandi-linked prices, verified FPO lots and institutional demand — built for the people who
              grow Karnataka&apos;s food.
            </p>

            <ul className="mt-7 hidden gap-3 text-[12.5px] text-white/85 sm:grid sm:grid-cols-2">
              {[
                "APMC-linked live price discovery",
                "Verified farmer & FPO lots",
                "No middlemen on direct trades",
                "Carbon-aware logistics insights",
              ].map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <CheckCircle2 size={15} className="shrink-0 text-[#a7e88a]" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="animate-fade hidden rounded-2xl border border-white/15 bg-[#04170f]/55 p-4 backdrop-blur-md sm:block sm:p-5">
            <div className="mb-3 flex items-center justify-between gap-2">
              <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-white/60">
                Today&apos;s mandi snapshot
              </span>
              <span className="inline-flex items-center gap-1.5 text-[10px] font-medium text-[#a7e88a]">
                <span className="live-dot h-1.5 w-1.5 rounded-full bg-[#7ce0a8]" />
                Live feed
              </span>
            </div>
            <div className="grid grid-cols-3 divide-x divide-white/10">
              {snapshotPrices.map(({ commodity, price, change }) => (
                <div key={commodity.id} className="px-2 first:pl-0 last:pr-0">
                  <div className="truncate text-[11px] text-white/65">{commodity.short}</div>
                  <div className="mt-1 font-mono text-[15px] font-medium text-white sm:text-[17px]">{fmtINR(price)}</div>
                  <div className="mt-0.5 flex items-center gap-1 text-[10.5px] text-[#a7e88a]">
                    <TrendingUp size={11} className={change < 0 ? "rotate-180" : ""} />
                    {change > 0 ? "+" : ""}
                    {change.toFixed(1)}%
                    <span className="hidden text-white/40 sm:inline">/qtl</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-center justify-between gap-3 border-t border-white/10 pt-3 text-[10.5px] text-white/50">
              <span className="inline-flex items-center gap-1.5">
                <ShieldCheck size={12} /> Prices simulated around AGMARKNET ranges
              </span>
              <span className="hidden font-mono sm:inline">09 mandis · 06 crops</span>
            </div>
          </div>
        </div>
      </aside>

      {/* ---------------- Form panel ---------------- */}
      <main className="relative flex flex-col" style={{ background: "var(--panel)" }}>
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.35]"
          style={{ background: "radial-gradient(circle at 88% 4%, var(--accent-soft), transparent 50%)" }}
        />
        <div className="relative z-10 flex flex-1 flex-col px-5 py-6 sm:px-10 sm:py-8">
          <div className="flex items-center justify-between gap-3">
            <div className="lg:hidden">
              <Logo />
            </div>
            <div className="ml-auto flex items-center gap-3">
              <span className="hidden text-[11.5px] sm:inline" style={{ color: "var(--muted)" }}>
                {mode === "signup" ? "Already trading with us?" : "New to GreenLink?"}
              </span>
              <button
                type="button"
                onClick={() => switchMode(mode === "signup" ? "signin" : "signup")}
                className="rounded-lg border px-3 py-1.5 text-[11.5px] font-semibold transition"
                style={{ borderColor: "var(--accent-line)", color: "var(--accent)", background: "var(--accent-soft)" }}
              >
                {mode === "signup" ? "Sign in" : "Create account"}
              </button>
              <ThemeToggle theme={theme} onToggle={onToggleTheme} />
            </div>
          </div>

          <div className="mx-auto flex w-full max-w-[400px] flex-1 flex-col justify-center py-8 sm:py-10">
            {mode === "reset" ? (
              <div className="animate-rise">
                <div
                  className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl"
                  style={{ background: "var(--accent-soft)", color: "var(--accent)", border: "1px solid var(--accent-line)" }}
                >
                  <Lock size={20} />
                </div>
                <h2 className="font-display text-[26px] font-semibold tracking-tight">Reset your password</h2>
                <p className="mt-1.5 text-[12.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
                  We&apos;ll send a secure reset link to the email registered with your workspace.
                </p>
                {resetSent ? (
                  <div className="mt-6 space-y-4">
                    <div
                      className="flex items-start gap-2.5 rounded-xl border p-3.5 text-[12px]"
                      style={{ borderColor: "var(--accent-line)", background: "var(--accent-soft)", color: "var(--accent)" }}
                    >
                      <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
                      <span>
                        Reset link sent to <strong>{email}</strong>. For this concept build, you can sign in with the demo
                        credentials.
                      </span>
                    </div>
                    <button type="button" className="btn-primary w-full py-2.5" onClick={() => switchMode("signin")}>
                      Back to sign in <ArrowRight size={15} />
                    </button>
                  </div>
                ) : (
                  <form className="mt-6 space-y-4" onSubmit={handleSubmit} noValidate>
                    <label className="flex flex-col gap-1.5">
                      <span className="text-[10.5px] font-semibold uppercase tracking-[0.09em]" style={{ color: "var(--muted)" }}>
                        Registered email
                      </span>
                      <div className="relative">
                        <Mail size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "var(--faint)" }} />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="you@greenlink.in"
                          className="field pl-9"
                          autoComplete="email"
                        />
                      </div>
                    </label>
                    {error && <p className="text-[11.5px]" style={{ color: "#e2694f" }}>{error}</p>}
                    <button type="submit" className="btn-primary w-full py-2.5" disabled={loading}>
                      {loading ? <Loader2 size={15} className="animate-spin" /> : <Mail size={15} />}
                      {loading ? "Sending link…" : "Send reset link"}
                    </button>
                    <button
                      type="button"
                      onClick={() => switchMode("signin")}
                      className="w-full text-center text-[11.5px] font-medium"
                      style={{ color: "var(--muted)" }}
                    >
                      Back to sign in
                    </button>
                  </form>
                )}
              </div>
            ) : (
              <>
                <div className="animate-rise">
                  <div className="mb-3 inline-flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-[0.15em]" style={{ color: "var(--accent)" }}>
                    <span className="h-px w-5" style={{ background: "var(--accent)" }} />
                    {mode === "signup" ? "Join the network" : "Trade workspace"}
                  </div>
                  <h2 className="font-display text-[27px] font-semibold leading-tight tracking-tight sm:text-[30px]">
                    {mode === "signup" ? "Create your account" : "Welcome back"}
                  </h2>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
                    {mode === "signup"
                      ? "Set up your Karnataka trade profile in less than a minute."
                      : "Sign in to see today's mandi prices and open trade lots."}
                  </p>
                </div>

                {mode === "signin" && (noticeText || notice) && !error && (
                  <div
                    className="mt-4 rounded-xl border px-3 py-2 text-[11.5px]"
                    style={{ borderColor: "var(--accent-line)", background: "var(--accent-soft)", color: "var(--accent)" }}
                  >
                    {noticeText || notice}
                  </div>
                )}

                <form className="mt-6 space-y-4" onSubmit={handleSubmit} noValidate>
                  <div>
                    <span className="mb-1.5 block text-[10.5px] font-semibold uppercase tracking-[0.09em]" style={{ color: "var(--muted)" }}>
                      I am a
                    </span>
                    <div className="grid grid-cols-3 gap-2">
                      {ROLES.map((r) => {
                        const Icon = r.icon;
                        const selected = role === r.id;
                        return (
                          <button
                            key={r.id}
                            type="button"
                            onClick={() => setRole(r.id)}
                            aria-pressed={selected}
                            className={cn(
                              "flex flex-col items-start gap-1 rounded-xl border p-2.5 text-left transition",
                              selected ? "shadow-sm" : "hover:brightness-[1.03]"
                            )}
                            style={{
                              borderColor: selected ? "var(--accent)" : "var(--line-strong)",
                              background: selected ? "var(--accent-soft)" : "var(--panel-2)",
                            }}
                          >
                            <Icon size={15} style={{ color: selected ? "var(--accent)" : "var(--muted)" }} />
                            <span className="text-[11.5px] font-semibold">{r.label}</span>
                            <span className="text-[9.5px] leading-tight" style={{ color: "var(--faint)" }}>{r.meta}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {mode === "signup" && (
                    <label className="flex flex-col gap-1.5">
                      <span className="text-[10.5px] font-semibold uppercase tracking-[0.09em]" style={{ color: "var(--muted)" }}>
                        {role === "fpo" ? "FPO / collective name" : "Full name"}
                      </span>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={role === "fpo" ? "Kaveri FPO Collective" : "Aruna Hegde"}
                        className="field"
                        autoComplete="name"
                      />
                    </label>
                  )}

                  <label className="flex flex-col gap-1.5">
                    <span className="text-[10.5px] font-semibold uppercase tracking-[0.09em]" style={{ color: "var(--muted)" }}>
                      Email address
                    </span>
                    <div className="relative">
                      <Mail size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "var(--faint)" }} />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@greenlink.in"
                        className="field pl-9"
                        autoComplete="email"
                      />
                    </div>
                  </label>

                  <label className="flex flex-col gap-1.5">
                    <span className="flex items-baseline justify-between gap-2">
                      <span className="text-[10.5px] font-semibold uppercase tracking-[0.09em]" style={{ color: "var(--muted)" }}>
                        Password
                      </span>
                      {mode === "signin" && (
                        <button
                          type="button"
                          onClick={() => switchMode("reset")}
                          className="text-[10.5px] font-medium hover:underline"
                          style={{ color: "var(--accent)" }}
                        >
                          Forgot password?
                        </button>
                      )}
                    </span>
                    <div className="relative">
                      <Lock size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "var(--faint)" }} />
                      <input
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="At least 6 characters"
                        className="field pl-9 pr-10"
                        autoComplete={mode === "signup" ? "new-password" : "current-password"}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword((v) => !v)}
                        aria-label={showPassword ? "Hide password" : "Show password"}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 transition hover:opacity-70"
                        style={{ color: "var(--faint)" }}
                      >
                        {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                      </button>
                    </div>
                  </label>

                  <div className="flex items-center justify-between gap-3">
                    <label className="flex cursor-pointer items-center gap-2 text-[11px]" style={{ color: "var(--muted)" }}>
                      <input
                        type="checkbox"
                        checked={remember}
                        onChange={(e) => setRemember(e.target.checked)}
                        className="h-3.5 w-3.5 rounded"
                      />
                      {mode === "signup" ? "Send me weekly price digests" : "Keep me signed in"}
                    </label>
                    <span className="font-mono text-[9.5px] uppercase tracking-wide" style={{ color: "var(--faint)" }}>
                      Secure access
                    </span>
                  </div>

                  {error && (
                    <p
                      role="alert"
                      className="rounded-lg border px-3 py-2 text-[11.5px]"
                      style={{ borderColor: "rgba(217,99,74,0.35)", background: "rgba(217,99,74,0.1)", color: "#e2694f" }}
                    >
                      {error}
                    </p>
                  )}

                  <button type="submit" className="btn-primary w-full py-2.5 text-[13px]" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 size={15} className="animate-spin" /> {mode === "signup" ? "Creating workspace…" : "Signing in…"}
                      </>
                    ) : (
                      <>
                        {mode === "signup" ? "Create workspace" : "Sign in to dashboard"} <ArrowRight size={15} />
                      </>
                    )}
                  </button>

                  <div className="flex items-center gap-3 py-0.5">
                    <span className="h-px flex-1" style={{ background: "var(--line)" }} />
                    <span className="text-[9.5px] font-medium uppercase tracking-[0.14em]" style={{ color: "var(--faint)" }}>
                      or
                    </span>
                    <span className="h-px flex-1" style={{ background: "var(--line)" }} />
                  </div>

                  <button
                    type="button"
                    onClick={() => completeLogin(true)}
                    disabled={loading}
                    className="btn-ghost w-full py-2.5"
                  >
                    <Sprout size={15} style={{ color: "var(--accent)" }} />
                    Explore with demo credentials
                  </button>
                </form>

                <div className="mt-5 rounded-xl border px-3 py-2.5" style={{ borderColor: "var(--line)", background: "var(--panel-2)" }}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 text-[10.5px] font-medium" style={{ color: "var(--muted)" }}>
                      <ShieldCheck size={12} style={{ color: "var(--accent)" }} /> Demo account pre-filled
                    </span>
                    <span className="font-mono text-[9.5px]" style={{ color: "var(--faint)" }}>
                      {DEMO_EMAIL} · {DEMO_PASSWORD}
                    </span>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border px-2.5 py-2 text-[10px]" style={{ borderColor: "var(--line)", color: "var(--faint)" }}>
                  <span>Downloaded ZIP? index.html not opening?</span>
                  <OfflineHelp label="Get the offline copy" />
                </div>

                <p className="mt-5 text-center text-[10.5px] leading-relaxed" style={{ color: "var(--faint)" }}>
                  By continuing you agree to GreenLink&apos;s{" "}
                  <a href="#terms" className="underline decoration-dotted" style={{ color: "var(--muted)" }}>Terms</a>,{" "}
                  <a href="#privacy" className="underline decoration-dotted" style={{ color: "var(--muted)" }}>Privacy Policy</a>{" "}
                  and fair-trade code of conduct.
                </p>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 border-t pt-4 text-[10px]" style={{ borderColor: "var(--line)", color: "var(--faint)" }}>
            <span>© 2026 GreenLink Karnataka · Concept workspace</span>
            <span className="flex flex-wrap items-center gap-3">
              <OfflineHelp variant="link" label="Offline copy & download help" />
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-[#3ad39a]" /> All prices simulated
              </span>
            </span>
          </div>
        </div>
      </main>
    </div>
  );
}
