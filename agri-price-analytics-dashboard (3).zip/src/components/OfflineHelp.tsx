import { useEffect, useState } from "react";
import {
  Check,
  Download,
  FileArchive,
  FileCode2,
  FolderOpen,
  HelpCircle,
  Loader2,
  MonitorDown,
  X,
} from "lucide-react";
import { cn } from "../utils/cn";
import { downloadStandaloneHtml, downloadWebsiteZip } from "../lib/offline";

function isFileProtocol() {
  return typeof window !== "undefined" && window.location.protocol === "file:";
}

export default function OfflineHelp({
  variant = "link",
  className,
  label,
}: {
  variant?: "link" | "button" | "icon";
  className?: string;
  label?: string;
}) {
  const [open, setOpen] = useState(false);
  const [fileMode, setFileMode] = useState(false);
  const [busy, setBusy] = useState<"html" | "zip" | null>(null);
  const [done, setDone] = useState<"html" | "zip" | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    setFileMode(isFileProtocol());
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [open]);

  async function handleHtml() {
    setError("");
    setBusy("html");
    try {
      await downloadStandaloneHtml();
      setDone("html");
    } catch {
      setError("Your browser blocked the download. Try the ZIP download instead.");
    } finally {
      setBusy(null);
    }
  }

  async function handleZip() {
    setError("");
    setBusy("zip");
    try {
      await downloadWebsiteZip();
      setDone("zip");
    } catch {
      setError("The ZIP could not be created in this browser. Use the single HTML download instead.");
    } finally {
      setBusy(null);
    }
  }

  const trigger =
    variant === "button" ? (
      <button type="button" onClick={() => setOpen(true)} className={cn("btn-ghost", className)}>
        <MonitorDown size={13} /> {label ?? "Download offline copy"}
      </button>
    ) : variant === "icon" ? (
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Open offline copy and download help"
        title="Download offline copy"
        className={cn(
          "flex h-9 w-9 items-center justify-center rounded-full border transition hover:brightness-105",
          className
        )}
        style={{ borderColor: "var(--line-strong)", background: "var(--panel-2)", color: "var(--muted)" }}
      >
        <MonitorDown size={15} />
      </button>
    ) : (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn("inline-flex items-center gap-1 font-medium underline decoration-dotted underline-offset-2", className)}
        style={{ color: "var(--muted)" }}
      >
        <HelpCircle size={11} /> {label ?? "ZIP or index.html not opening?"}
      </button>
    );

  return (
    <>
      {trigger}

      {open && (
        <div
          className="fixed inset-0 z-[60] flex items-end justify-center p-0 sm:items-center sm:p-6"
          style={{ background: "rgba(3, 14, 9, 0.62)", backdropFilter: "blur(5px)" }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="offline-help-title"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setOpen(false);
          }}
        >
          <div
            className="animate-rise max-h-[92vh] w-full max-w-[540px] overflow-y-auto rounded-t-2xl border shadow-2xl sm:rounded-2xl"
            style={{ background: "var(--panel)", borderColor: "var(--line)", boxShadow: "var(--shadow-lift)" }}
          >
            <div className="flex items-start justify-between gap-3 border-b px-5 py-4" style={{ borderColor: "var(--line)" }}>
              <div className="flex items-start gap-3">
                <div
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                  style={{ background: "var(--accent-soft)", color: "var(--accent)", border: "1px solid var(--accent-line)" }}
                >
                  <MonitorDown size={17} />
                </div>
                <div>
                  <h2 id="offline-help-title" className="font-display text-[15px] font-semibold leading-tight">
                    Open GreenLink on your laptop
                  </h2>
                  <p className="mt-1 text-[11px] leading-relaxed" style={{ color: "var(--muted)" }}>
                    Get a copy that runs by double-clicking one file — no installation, no server, no internet required.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close"
                className="rounded-lg p-1 transition hover:opacity-70"
                style={{ color: "var(--faint)" }}
              >
                <X size={17} />
              </button>
            </div>

            <div className="px-5 py-4">
              {fileMode ? (
                <div
                  className="mb-4 flex items-start gap-2 rounded-xl border p-3 text-[11.5px] leading-relaxed"
                  style={{ borderColor: "var(--accent-line)", background: "var(--accent-soft)", color: "var(--accent)" }}
                >
                  <Check size={14} className="mt-0.5 shrink-0" />
                  <span>
                    Good news — this page is already the offline copy, opened straight from your laptop. It needs no
                    installation. Close this note and sign in to continue.
                  </span>
                </div>
              ) : (
                <>
                  <div className="mb-2 grid gap-2 sm:grid-cols-2">
                    <button
                      type="button"
                      onClick={handleHtml}
                      disabled={busy !== null}
                      className="btn-primary flex-col items-start gap-1 px-3.5 py-2.5 text-left text-[11.5px]"
                    >
                      <span className="inline-flex items-center gap-1.5">
                        {busy === "html" ? <Loader2 size={13} className="animate-spin" /> : <FileCode2 size={13} />}
                        {busy === "html" ? "Preparing file…" : "Download index.html"}
                      </span>
                      <span className="text-[9.5px] font-medium opacity-80">Easiest · no unzip needed</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleZip}
                      disabled={busy !== null}
                      className="btn-ghost flex-col items-start gap-1 px-3.5 py-2.5 text-left text-[11.5px]"
                    >
                      <span className="inline-flex items-center gap-1.5">
                        {busy === "zip" ? <Loader2 size={13} className="animate-spin" /> : <FileArchive size={13} />}
                        {busy === "zip" ? "Creating ZIP…" : "Download website ZIP"}
                      </span>
                      <span className="text-[9.5px]" style={{ color: "var(--faint)" }}>Includes index.html + README</span>
                    </button>
                  </div>
                  <div className="mb-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-[9.5px]" style={{ color: "var(--faint)" }}>
                    <span className="inline-flex items-center gap-1"><Check size={10} /> Works without internet</span>
                    <span className="inline-flex items-center gap-1"><Check size={10} /> Exactly this dashboard</span>
                    <span className="inline-flex items-center gap-1"><Download size={10} /> Saved to Downloads</span>
                  </div>
                  {(done || error) && (
                    <div
                      className="mb-4 flex items-start gap-2 rounded-xl border p-2.5 text-[10.5px] leading-relaxed"
                      style={{
                        borderColor: error ? "rgba(217,99,74,0.35)" : "var(--accent-line)",
                        background: error ? "rgba(217,99,74,0.1)" : "var(--accent-soft)",
                        color: error ? "#e2694f" : "var(--accent)",
                      }}
                    >
                      {error ? <HelpCircle size={13} className="mt-0.5 shrink-0" /> : <Check size={13} className="mt-0.5 shrink-0" />}
                      <span>
                        {error ||
                          (done === "html"
                            ? "index.html downloaded. Find it in your Downloads folder and double-click it."
                            : "ZIP downloaded. Extract it, then open the GreenLink-Karnataka folder and double-click index.html.")}
                      </span>
                    </div>
                  )}
                </>
              )}

              <div className="space-y-2.5">
                {[
                  {
                    title: "Download the file",
                    body: "Use “Download index.html” above. It is the entire website in one file — nothing else to install.",
                  },
                  {
                    title: "Don't open it from inside the ZIP",
                    body: "If you chose the ZIP, right-click → “Extract All…” (Windows) or double-click it (macOS) first. Opening index.html from a ZIP preview is what usually causes a blank page.",
                  },
                  {
                    title: "Double-click index.html",
                    body: "It opens in Chrome, Edge, Firefox or Safari. If your laptop opens a code editor instead, right-click the file → “Open with” → choose your browser.",
                  },
                  {
                    title: "Sign in and explore",
                    body: "Demo email demo@greenlink.in, password greenlink123 — or press “Explore with demo credentials”.",
                  },
                ].map((step, index) => (
                  <div key={step.title} className="flex gap-2.5">
                    <span
                      className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full font-mono text-[10px] font-semibold"
                      style={{ background: "var(--accent-soft)", color: "var(--accent)", border: "1px solid var(--accent-line)" }}
                    >
                      {index + 1}
                    </span>
                    <div>
                      <p className="text-[11.5px] font-semibold leading-tight">{step.title}</p>
                      <p className="mt-0.5 text-[10.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
                        {step.body}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 rounded-xl border p-3" style={{ borderColor: "var(--line)", background: "var(--panel-2)" }}>
                <div className="flex items-start gap-2">
                  <HelpCircle size={13} className="mt-0.5 shrink-0" style={{ color: "var(--accent)" }} />
                  <div className="text-[10.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
                    <strong className="font-semibold" style={{ color: "var(--text)" }}>Received a project folder instead?</strong>{" "}
                    The top-level <span className="font-mono">index.html</span> in that folder is the developer entry file and
                    shows a blank page if opened directly. Use the download buttons above, or after extracting the project run{" "}
                    <span className="font-mono">npm install</span> then <span className="font-mono">npm run build</span> and open{" "}
                    <span className="font-mono">dist/index.html</span>.
                  </div>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-3 text-[10px]" style={{ color: "var(--faint)" }}>
                <span className="inline-flex items-center gap-1.5"><FolderOpen size={11} /> Offline ready</span>
                <span className="inline-flex items-center gap-1.5"><Check size={11} /> No server needed</span>
                <span className="inline-flex items-center gap-1.5"><FileArchive size={11} /> ZIP includes README</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
