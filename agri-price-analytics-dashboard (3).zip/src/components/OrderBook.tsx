import { useMemo, useState } from "react";
import { ArrowDownUp, ArrowLeftRight, Filter, Sparkles } from "lucide-react";
import { cn } from "../utils/cn";
import {
  COMMODITIES,
  PRACTICES,
  REGIONS,
  findBestMatch,
  fmtINR,
  fmtTonnes,
  getCommodity,
  getPractice,
  getRegion,
  type BuyerBid,
  type FarmerOffer,
} from "../lib/data";
import { CommodityMark, EmptyState, SectionHead } from "./ui";

export default function OrderBook({
  offers,
  bids,
  commodityFilter,
  onCommodityFilterChange,
}: {
  offers: FarmerOffer[];
  bids: BuyerBid[];
  commodityFilter: string;
  onCommodityFilterChange: (value: string) => void;
}) {
  const [regionFilter, setRegionFilter] = useState("all");
  const [practiceFilter, setPracticeFilter] = useState("all");

  const filteredOffers = useMemo(
    () =>
      offers
        .filter((o) => commodityFilter === "all" || o.commodityId === commodityFilter)
        .filter((o) => regionFilter === "all" || o.regionId === regionFilter)
        .filter((o) => practiceFilter === "all" || o.practice === practiceFilter)
        .sort((a, b) => a.price - b.price),
    [offers, commodityFilter, regionFilter, practiceFilter]
  );

  const filteredBids = useMemo(
    () =>
      bids
        .filter((b) => commodityFilter === "all" || b.commodityId === commodityFilter)
        .filter((b) => regionFilter === "all" || b.regionId === regionFilter)
        .sort((a, b) => b.price - a.price),
    [bids, commodityFilter, regionFilter]
  );

  const best = useMemo(() => findBestMatch(filteredOffers, filteredBids), [filteredOffers, filteredBids]);

  const avgUplift = useMemo(() => {
    if (!filteredOffers.length) return 0;
    const total = filteredOffers.reduce((sum, offer) => {
      const baseline = getCommodity(offer.commodityId)?.baseline ?? offer.price;
      return sum + ((offer.price - baseline) / baseline) * 100;
    }, 0);
    return total / filteredOffers.length;
  }, [filteredOffers]);

  const floorCommodity =
    commodityFilter === "all" ? COMMODITIES[0] : getCommodity(commodityFilter) ?? COMMODITIES[0];

  return (
    <div id="market" className="surface flex flex-col p-4 sm:p-5">
      <SectionHead
        icon={<ArrowLeftRight size={15} />}
        title="Farmer offers & buyer bids"
        subtitle="Match verified lots from Karnataka districts with institutional demand."
        actions={
          <div className="flex flex-wrap items-center gap-1.5">
            <select
              value={commodityFilter}
              onChange={(e) => onCommodityFilterChange(e.target.value)}
              className="field w-[134px] py-1.5 text-[11px]"
              aria-label="Filter by commodity"
            >
              <option value="all">All commodities</option>
              {COMMODITIES.map((c) => (
                <option key={c.id} value={c.id}>{c.short}</option>
              ))}
            </select>
            <select
              value={regionFilter}
              onChange={(e) => setRegionFilter(e.target.value)}
              className="field w-[142px] py-1.5 text-[11px]"
              aria-label="Filter by region"
            >
              <option value="all">All 9 regions</option>
              {REGIONS.map((r) => (
                <option key={r.id} value={r.id}>{r.district}</option>
              ))}
            </select>
            <select
              value={practiceFilter}
              onChange={(e) => setPracticeFilter(e.target.value)}
              className="field w-[132px] py-1.5 text-[11px]"
              aria-label="Filter by practice"
            >
              <option value="all">All practices</option>
              {PRACTICES.map((p) => (
                <option key={p.id} value={p.id}>{p.short} only</option>
              ))}
            </select>
          </div>
        }
        compact
      />

      <div className="mt-3.5 grid flex-1 gap-3 md:grid-cols-2">
        <div className="flex min-h-0 flex-col overflow-hidden rounded-xl border" style={{ borderColor: "var(--line)" }}>
          <div
            className="flex items-center justify-between gap-2 border-b px-3 py-2"
            style={{ borderColor: "var(--line)", background: "var(--accent-soft)" }}
          >
            <span className="flex items-center gap-1.5 text-[11px] font-semibold" style={{ color: "var(--accent)" }}>
              <ArrowDownUp size={12} /> Farmer offers
            </span>
            <span className="text-[9px] uppercase tracking-[0.07em]" style={{ color: "var(--muted)" }}>Min → max ask</span>
          </div>
          <div className="scroll-thin max-h-[286px] flex-1 divide-y overflow-y-auto" style={{ borderColor: "var(--line)" }}>
            {filteredOffers.length ? (
              filteredOffers.map((offer) => {
                const region = getRegion(offer.regionId);
                const practice = getPractice(offer.practice);
                const isBest = best?.offer.id === offer.id;
                return (
                  <div
                    key={offer.id}
                    className="group flex items-center gap-2.5 px-3 py-2 transition hover:bg-[var(--panel-2)]"
                    style={{
                      borderLeft: `2px solid ${isBest ? "var(--accent)" : "transparent"}`,
                      background: isBest ? "var(--accent-soft)" : undefined,
                    }}
                  >
                    <CommodityMark id={offer.commodityId} size={24} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="truncate text-[11px] font-semibold">{getCommodity(offer.commodityId)?.short}</span>
                        <span className="shrink-0 font-mono text-[11px] font-semibold" style={{ color: "var(--accent)" }}>
                          {fmtINR(offer.price)}
                        </span>
                      </div>
                      <div className="mt-0.5 flex items-baseline justify-between gap-2 text-[9.5px]" style={{ color: "var(--faint)" }}>
                        <span className="truncate">{region?.district} · {region?.market.replace(" APMC", "")}</span>
                        <span className="shrink-0">{fmtTonnes(offer.quantity)}</span>
                      </div>
                      <div className="mt-1 flex items-center gap-1.5">
                        <span className="rounded px-1.5 py-px text-[8.5px] font-medium" style={{ background: "var(--panel-3)", color: "var(--muted)" }}>
                          {practice?.short}
                        </span>
                        {isBest && (
                          <span className="inline-flex items-center gap-0.5 rounded px-1.5 py-px text-[8.5px] font-semibold" style={{ background: "var(--accent)", color: "var(--accent-ink)" }}>
                            <Sparkles size={8} /> Best ask
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <EmptyState>No farmer offers for current filters.</EmptyState>
            )}
          </div>
        </div>

        <div className="flex min-h-0 flex-col overflow-hidden rounded-xl border" style={{ borderColor: "var(--line)" }}>
          <div className="flex items-center justify-between gap-2 border-b px-3 py-2" style={{ borderColor: "var(--line)", background: "rgba(26,127,168,0.08)" }}>
            <span className="flex items-center gap-1.5 text-[11px] font-semibold" style={{ color: "var(--sky)" }}>
              <ArrowDownUp size={12} /> Buyer bids
            </span>
            <span className="text-[9px] uppercase tracking-[0.07em]" style={{ color: "var(--muted)" }}>Max → min bid</span>
          </div>
          <div className="scroll-thin max-h-[286px] flex-1 divide-y overflow-y-auto" style={{ borderColor: "var(--line)" }}>
            {filteredBids.length ? (
              filteredBids.map((bid) => {
                const region = getRegion(bid.regionId);
                const isBest = best?.bid.id === bid.id;
                return (
                  <div
                    key={bid.id}
                    className="group flex items-center gap-2.5 px-3 py-2 transition hover:bg-[var(--panel-2)]"
                    style={{
                      borderLeft: `2px solid ${isBest ? "var(--sky)" : "transparent"}`,
                      background: isBest ? "rgba(26,127,168,0.06)" : undefined,
                    }}
                  >
                    <CommodityMark id={bid.commodityId} size={24} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="truncate text-[11px] font-semibold">{getCommodity(bid.commodityId)?.short}</span>
                        <span className="shrink-0 font-mono text-[11px] font-semibold" style={{ color: "var(--sky)" }}>
                          {fmtINR(bid.price)}
                        </span>
                      </div>
                      <div className="mt-0.5 flex items-baseline justify-between gap-2 text-[9.5px]" style={{ color: "var(--faint)" }}>
                        <span className="truncate">{region?.district} · {region?.market.replace(" APMC", "")}</span>
                        <span className="shrink-0">{fmtTonnes(bid.quantity)}</span>
                      </div>
                      <div className="mt-1 flex items-center gap-1.5">
                        <span className="rounded px-1.5 py-px text-[8.5px] font-medium capitalize" style={{ background: "var(--panel-3)", color: "var(--muted)" }}>
                          {bid.contract}
                        </span>
                        {isBest && (
                          <span className="inline-flex items-center gap-0.5 rounded px-1.5 py-px text-[8.5px] font-semibold" style={{ background: "var(--sky)", color: "#04160e" }}>
                            <Sparkles size={8} /> Best bid
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <EmptyState>No buyer bids for current filters.</EmptyState>
            )}
          </div>
        </div>
      </div>

      <div className="mt-3 grid gap-2 rounded-xl border px-3 py-2.5 sm:grid-cols-[1.5fr_1fr_1fr]" style={{ borderColor: "var(--line)", background: "var(--panel-2)" }}>
        <div className="min-w-0">
          <div className="text-[9px] uppercase tracking-[0.08em]" style={{ color: "var(--faint)" }}>Best match for filter</div>
          <div className="mt-0.5 truncate font-mono text-[10.5px] font-medium" style={{ color: "var(--accent)" }}>
            {best
              ? `${getCommodity(best.offer.commodityId)?.short}: ${fmtINR(best.offer.price)} → ${fmtINR(best.bid.price)} · ${fmtTonnes(best.quantity)}`
              : "No overlap yet — adjust ask or bid"}
          </div>
        </div>
        <div>
          <div className="text-[9px] uppercase tracking-[0.08em]" style={{ color: "var(--faint)" }}>Avg. farmgate uplift</div>
          <div className={cn("mt-0.5 font-mono text-[10.5px] font-medium")} style={{ color: avgUplift >= 0 ? "var(--accent)" : "var(--amber)" }}>
            {avgUplift >= 0 ? "+" : ""}{avgUplift.toFixed(1)}% vs baseline
          </div>
        </div>
        <div>
          <div className="flex items-center gap-1 text-[9px] uppercase tracking-[0.08em]" style={{ color: "var(--faint)" }}>
            {floorCommodity.benchmark}
          </div>
          <div className="mt-0.5 font-mono text-[10.5px] font-medium">
            {fmtINR(floorCommodity.baseline)}/quintal
          </div>
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between text-[9.5px]" style={{ color: "var(--faint)" }}>
        <span className="inline-flex items-center gap-1"><Filter size={10} /> Showing {filteredOffers.length} offers · {filteredBids.length} bids</span>
        <span>Ranked by best price · simulated book</span>
      </div>
    </div>
  );
}
