import { useEffect, useState, type FormEvent } from "react";
import { Calculator, IndianRupee, Info, ShieldCheck, Sparkles } from "lucide-react";
import {
  COMMODITIES,
  REGIONS,
  fmtINR,
  fmtNumber,
  getCommodity,
  getRegion,
  type BuyerBid,
  type FarmerOffer,
} from "../lib/data";
import { LabeledField, SectionHead } from "./ui";

interface Estimate {
  total: number;
  ratePerKg: number;
  ratePerQuintal: number;
  source: string;
  quantityKg: number;
  saving: number;
  benchmark: number;
  commodityName: string;
  regionLabel: string;
}

export default function PriceCalculator({
  offers,
  bids,
}: {
  offers: FarmerOffer[];
  bids: BuyerBid[];
}) {
  const [cropId, setCropId] = useState("paddy");
  const [regionId, setRegionId] = useState("mandya");
  const [quantity, setQuantity] = useState("25");
  const [unit, setUnit] = useState<"kg" | "quintal">("quintal");
  const [error, setError] = useState("");
  const [estimate, setEstimate] = useState<Estimate | null>(null);

  function compute() {
    const commodity = getCommodity(cropId);
    const region = getRegion(regionId);
    const qty = Number.parseFloat(quantity);

    if (!commodity || !region) {
      setError("Select a crop and a mandi to estimate a price.");
      return;
    }
    if (!Number.isFinite(qty) || qty <= 0) {
      setError("Enter a quantity greater than zero.");
      return;
    }

    const localOffers = offers.filter((o) => o.commodityId === cropId && o.regionId === regionId);
    const localBids = bids.filter((b) => b.commodityId === cropId && b.regionId === regionId);

    let ratePerQuintal = commodity.baseline;
    let source = "Karnataka baseline reference";

    if (localOffers.length && localBids.length) {
      const avgAsk = localOffers.reduce((s, o) => s + o.price, 0) / localOffers.length;
      const avgBid = localBids.reduce((s, b) => s + b.price, 0) / localBids.length;
      ratePerQuintal = Math.round((avgAsk + avgBid) / 2);
      source = `${region.market} · live order book`;
    } else if (localOffers.length) {
      ratePerQuintal = Math.round(localOffers.reduce((s, o) => s + o.price, 0) / localOffers.length);
      source = `${region.market} · farmer asks`;
    } else if (localBids.length) {
      ratePerQuintal = Math.round(localBids.reduce((s, b) => s + b.price, 0) / localBids.length);
      source = `${region.market} · buyer bids`;
    }

    const quantityKg = unit === "kg" ? qty : qty * 100;
    const ratePerKg = ratePerQuintal / 100;
    const total = ratePerKg * quantityKg;

    setEstimate({
      total,
      ratePerKg,
      ratePerQuintal,
      source,
      quantityKg,
      saving: total * 0.078,
      benchmark: commodity.baseline,
      commodityName: commodity.name,
      regionLabel: region.label,
    });
    setError("");
  }

  useEffect(() => {
    compute();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    compute();
  }

  const delta = estimate ? ((estimate.ratePerQuintal - estimate.benchmark) / estimate.benchmark) * 100 : 0;

  return (
    <section className="surface overflow-hidden" aria-labelledby="calculator-title">
      <div className="p-4 sm:p-5">
        <SectionHead
          icon={<Calculator size={15} />}
          title="Price Calculator"
          subtitle="Enter a quantity and select a crop to estimate value from today's Karnataka order book."
          actions={
            <span className="chip">
              <ShieldCheck size={11} /> Live mandi rates
            </span>
          }
        />

        <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-2.5 md:grid-cols-12">
          <LabeledField label="Crop type" className="col-span-2 md:col-span-3">
            <select value={cropId} onChange={(e) => setCropId(e.target.value)} className="field" aria-label="Crop type">
              {COMMODITIES.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </LabeledField>

          <LabeledField label="Location / mandi" className="col-span-2 md:col-span-4">
            <select value={regionId} onChange={(e) => setRegionId(e.target.value)} className="field" aria-label="Location / mandi">
              {REGIONS.map((r) => (
                <option key={r.id} value={r.id}>{r.label}</option>
              ))}
            </select>
          </LabeledField>

          <LabeledField label="Quantity" className="col-span-1 md:col-span-2">
            <input
              type="number"
              min="0"
              step="0.1"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder="e.g. 25"
              className="field tabular"
              aria-label="Quantity"
            />
          </LabeledField>

          <LabeledField label="Unit" className="col-span-1 md:col-span-1">
            <select value={unit} onChange={(e) => setUnit(e.target.value as "kg" | "quintal")} className="field" aria-label="Unit">
              <option value="quintal">Qtl</option>
              <option value="kg">kg</option>
            </select>
          </LabeledField>

          <div className="col-span-2 flex flex-col gap-1.5 md:col-span-2">
            <span className="hidden text-[10.5px] font-medium uppercase tracking-[0.09em] md:block" style={{ color: "transparent" }}>
              Estimate
            </span>
            <button type="submit" className="btn-primary h-[37px] w-full whitespace-nowrap">
              <Sparkles size={13} /> Calculate
            </button>
          </div>

          <p className="col-span-2 flex items-center gap-1.5 text-[10px] md:col-span-12" style={{ color: "var(--faint)" }}>
            <Info size={11} /> Quick entry: 1 tonne = 10 quintals. Rates are indicative and exclude transport and GST.
          </p>
          {error && (
            <p role="alert" className="col-span-2 text-[11px] md:col-span-12" style={{ color: "#e2694f" }}>{error}</p>
          )}
        </form>
      </div>

      {estimate && (
        <div
          key={`${estimate.total}-${estimate.source}`}
          className="animate-rise border-t px-4 py-4 sm:px-5"
          style={{ borderColor: "var(--accent-line)", background: "linear-gradient(110deg, var(--accent-soft), transparent 62%)" }}
        >
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-semibold uppercase tracking-[0.13em]" style={{ color: "var(--accent)" }}>
                  Estimated price
                </span>
                <span
                  className="rounded-full px-1.5 py-0.5 font-mono text-[9.5px] font-semibold"
                  style={{
                    color: delta >= 0 ? "var(--accent)" : "var(--amber)",
                    background: delta >= 0 ? "var(--accent-soft)" : "var(--amber-soft)",
                  }}
                >
                  {delta >= 0 ? "+" : ""}{delta.toFixed(1)}% vs benchmark
                </span>
              </div>
              <div className="mt-1 flex flex-wrap items-end gap-x-3 gap-y-1">
                <span className="font-display text-[28px] font-semibold leading-none tracking-tight sm:text-[32px]">
                  {fmtINR(estimate.total)}
                </span>
                <span className="pb-0.5 text-[11px]" style={{ color: "var(--muted)" }}>
                  for {fmtNumber(estimate.quantityKg, estimate.quantityKg % 1 === 0 ? 0 : 1)} kg of {estimate.commodityName}
                </span>
              </div>
              <p className="mt-1.5 text-[10.5px] leading-relaxed" style={{ color: "var(--muted)" }}>
                Based on {estimate.source} at {fmtINR(estimate.ratePerQuintal)}/quintal · {estimate.regionLabel}
              </p>
            </div>

            <div className="grid shrink-0 grid-cols-3 gap-2 lg:max-w-[440px]">
              {[
                { label: "Per-unit rate", value: `${fmtINR(estimate.ratePerKg, 2)}/kg`, icon: <IndianRupee size={11} /> },
                { label: "Benchmark floor", value: `${fmtINR(estimate.benchmark)}/qtl`, icon: <ShieldCheck size={11} /> },
                { label: "Direct-trade edge", value: `~${fmtINR(estimate.saving)}`, icon: <Sparkles size={11} /> },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-xl border px-2.5 py-2"
                  style={{ borderColor: "var(--line)", background: "var(--panel)" }}
                >
                  <span className="flex items-center gap-1 text-[9px] uppercase tracking-[0.05em]" style={{ color: "var(--faint)" }}>
                    {stat.icon} {stat.label}
                  </span>
                  <span className="mt-1 block font-mono text-[12px] font-semibold">{stat.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
