import { ArrowDownRight, ArrowUpRight, RefreshCw, SlidersHorizontal } from "lucide-react";
import { cn } from "../utils/cn";
import {
  COMMODITIES,
  fmtINR,
  fmtTime,
  fmtTonnes,
  snapshotFor,
  type BuyerBid,
  type FarmerOffer,
} from "../lib/data";
import { CommodityMark, EmptyState, SectionHead } from "./ui";

export default function PriceTicker({
  offers,
  bids,
  filter,
  onFilterChange,
  autoRefresh,
  onToggleAutoRefresh,
  onRefresh,
  lastUpdated,
}: {
  offers: FarmerOffer[];
  bids: BuyerBid[];
  filter: string;
  onFilterChange: (value: string) => void;
  autoRefresh: boolean;
  onToggleAutoRefresh: (value: boolean) => void;
  onRefresh: () => void;
  lastUpdated: Date;
}) {
  const visible = COMMODITIES.filter((c) => filter === "all" || c.id === filter);

  return (
    <div className="surface flex h-full flex-col p-4 sm:p-5">
      <SectionHead
        icon={<SlidersHorizontal size={14} />}
        title="Live Karnataka price snapshot"
        subtitle="Simulated around MSP and recent mandi ranges across 9 districts."
        actions={
          <select
            value={filter}
            onChange={(e) => onFilterChange(e.target.value)}
            className="field w-[142px] py-1.5 text-[11px]"
            aria-label="Filter commodity"
          >
            <option value="all">All commodities</option>
            {COMMODITIES.map((c) => (
              <option key={c.id} value={c.id}>{c.short}</option>
            ))}
          </select>
        }
        compact
      />

      <div className="mt-3 flex-1">
        <div className="scroll-thin flex gap-2.5 overflow-x-auto pb-2">
          {visible.map((commodity) => {
            const snap = snapshotFor(commodity.id, offers, bids);
            if (!snap) return null;
            const positive = snap.vsBenchmark >= 0;
            return (
              <button
                type="button"
                key={commodity.id}
                onClick={() => onFilterChange(filter === commodity.id ? "all" : commodity.id)}
                className={cn(
                  "group relative min-w-[174px] flex-1 rounded-xl border p-3 text-left transition",
                  filter === commodity.id ? "shadow-sm" : "hover:brightness-[1.03]"
                )}
                style={{
                  borderColor: filter === commodity.id ? "var(--accent)" : "var(--line)",
                  background: filter === commodity.id ? "var(--accent-soft)" : "var(--panel-2)",
                }}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2">
                    <CommodityMark id={commodity.id} size={24} />
                    <span className="truncate text-[11.5px] font-semibold">{commodity.short}</span>
                  </div>
                  <span
                    className="flex items-center gap-0.5 font-mono text-[9.5px] font-medium"
                    style={{ color: positive ? "var(--accent)" : "var(--amber)" }}
                  >
                    {positive ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                    {positive ? "+" : ""}{snap.vsBenchmark.toFixed(1)}%
                  </span>
                </div>
                <div className="mt-2 font-mono text-[16px] font-semibold leading-none">{fmtINR(snap.mid)}</div>
                <div className="mt-0.5 text-[9px] uppercase tracking-[0.08em]" style={{ color: "var(--faint)" }}>
                  per quintal · mid
                </div>
                <div className="mt-2.5 grid grid-cols-2 gap-1 border-t pt-2 text-[10px]" style={{ borderColor: "var(--line)" }}>
                  <span style={{ color: "var(--faint)" }}>
                    Ask <span className="font-mono font-medium" style={{ color: "var(--accent)" }}>{fmtINR(snap.minAsk)}</span>
                  </span>
                  <span className="text-right" style={{ color: "var(--faint)" }}>
                    Bid <span className="font-mono font-medium" style={{ color: "var(--sky)" }}>{fmtINR(snap.maxBid)}</span>
                  </span>
                  <span style={{ color: "var(--faint)" }}>
                    Spread <span className="font-mono" style={{ color: "var(--text)" }}>{fmtINR(snap.spread)}</span>
                  </span>
                  <span className="text-right" style={{ color: "var(--faint)" }}>
                    Depth <span className="font-mono" style={{ color: "var(--text)" }}>{snap.depth}%</span>
                  </span>
                </div>
                <div className="mt-2 h-1 w-full overflow-hidden rounded-full" style={{ background: "var(--panel-3)" }}>
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${snap.depth}%`, background: "linear-gradient(90deg, var(--accent), var(--lime))" }}
                  />
                </div>
                <span className="mt-2 block text-[9px]" style={{ color: "var(--faint)" }}>
                  {fmtTonnes(snap.volume)} offered · {snap.offers + snap.bids} lots
                </span>
              </button>
            );
          })}
          {!visible.length && <EmptyState>No commodities match this filter.</EmptyState>}
        </div>
      </div>

      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t pt-3" style={{ borderColor: "var(--line)" }}>
        <div className="flex items-center gap-1.5 text-[10px]" style={{ color: "var(--faint)" }}>
          <span className="live-dot h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} />
          Last update <span className="font-mono" style={{ color: "var(--muted)" }}>{fmtTime(lastUpdated)}</span>
          <span className="hidden sm:inline">· Spread = bid − ask (₹/qtl)</span>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex cursor-pointer items-center gap-1.5 text-[10.5px]" style={{ color: "var(--muted)" }}>
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => onToggleAutoRefresh(e.target.checked)}
              className="h-3 w-3 rounded"
            />
            Auto-refresh
          </label>
          <button type="button" onClick={onRefresh} className="btn-subtle px-2.5 py-1.5 text-[10.5px]">
            <RefreshCw size={11} /> Refresh
          </button>
        </div>
      </div>
    </div>
  );
}
