import { useMemo } from "react";
import { Check, Leaf, MapPin, ShieldCheck, Truck } from "lucide-react";
import { fmtTonnes, seededRandom, type BuyerBid, type FarmerOffer } from "../lib/data";
import { SectionHead } from "./ui";

export default function Sustainability({
  offers,
  bids,
  tick,
}: {
  offers: FarmerOffer[];
  bids: BuyerBid[];
  tick: number;
}) {
  const stats = useMemo(() => {
    const volume = [...offers, ...bids].reduce((sum, lot) => sum + lot.quantity, 0);
    const emissions = 29 + seededRandom(tick + 5) * 13;
    const foodLoss = 18 + volume * 0.028;
    const traceability = 78 + seededRandom(tick + 9) * 11;
    return { emissions, foodLoss, traceability, volume };
  }, [offers, bids, tick]);

  const certifications = useMemo(
    () => [
      { label: "Farmer KYC & RTC (pahani) uploaded", active: true },
      { label: "Geo-tagged fields in Karnataka", active: true },
      { label: "State organic / IPM certification", active: true },
      { label: "FPO membership verified", active: true },
      { label: "e-NAM / APMC lot linkage", active: stats.traceability > 84 },
    ],
    [stats.traceability]
  );

  return (
    <div id="sustainability" className="surface p-4 sm:p-5">
      <SectionHead
        icon={<Leaf size={14} />}
        title="Sustainability & impact"
        subtitle="Karnataka-focused emissions, food loss and traceability indicators."
        actions={
          <span className="rounded-full border px-2 py-1 text-[9px] font-medium uppercase tracking-[0.06em]" style={{ borderColor: "var(--accent-line)", background: "var(--accent-soft)", color: "var(--accent)" }}>
            Beta impact index
          </span>
        }
        compact
      />

      <div className="mt-3.5 grid grid-cols-2 gap-2.5">
        <div className="surface-soft flex flex-col gap-2 p-3">
          <div className="flex items-center justify-between gap-1">
            <span className="text-[10px]" style={{ color: "var(--faint)" }}>Emissions vs. baseline</span>
            <Truck size={11} style={{ color: "var(--accent)" }} />
          </div>
          <span className="font-display text-[18px] font-semibold leading-none" style={{ color: "var(--accent)" }}>
            −{stats.emissions.toFixed(0)}%
          </span>
          <div className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--panel-3)" }}>
            <div className="h-full rounded-full transition-all duration-700" style={{ width: `${stats.emissions}%`, background: "linear-gradient(90deg, var(--accent), var(--lime))" }} />
          </div>
          <p className="text-[9px] leading-relaxed" style={{ color: "var(--faint)" }}>
            Shorter routes to Bengaluru, Mysuru & Hubballi hubs.
          </p>
        </div>

        <div className="surface-soft flex flex-col gap-2 p-3">
          <div className="flex items-center justify-between gap-1">
            <span className="text-[10px]" style={{ color: "var(--faint)" }}>Food loss avoided</span>
            <Leaf size={11} style={{ color: "var(--sky)" }} />
          </div>
          <span className="font-display text-[18px] font-semibold leading-none" style={{ color: "var(--sky)" }}>
            {fmtTonnes(stats.foodLoss)}
          </span>
          <div className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--panel-3)" }}>
            <div className="h-full rounded-full transition-all duration-700" style={{ width: `${Math.min(100, stats.foodLoss * 2.4)}%`, background: "linear-gradient(90deg, var(--sky), var(--accent))" }} />
          </div>
          <p className="text-[9px] leading-relaxed" style={{ color: "var(--faint)" }}>
            Better demand signals into Bengaluru and tier-2 cities.
          </p>
        </div>
      </div>

      <div className="mt-2.5 rounded-xl border p-3" style={{ borderColor: "var(--line)", background: "var(--panel-2)" }}>
        <div className="flex items-center justify-between gap-2">
          <span className="flex items-center gap-1.5 text-[10.5px] font-medium" style={{ color: "var(--muted)" }}>
            <ShieldCheck size={12} style={{ color: "var(--accent)" }} /> Traceability & certifications
          </span>
          <span className="font-mono text-[10.5px] font-semibold" style={{ color: "var(--accent)" }}>{stats.traceability.toFixed(0)}%</span>
        </div>
        <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--panel-3)" }}>
          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${stats.traceability}%`, background: "linear-gradient(90deg, var(--accent), var(--sky))" }} />
        </div>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {certifications.map((cert) => (
            <span
              key={cert.label}
              className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[9px]"
              style={{
                borderColor: cert.active ? "var(--accent-line)" : "var(--line-strong)",
                background: cert.active ? "var(--accent-soft)" : "var(--panel)",
                color: cert.active ? "var(--accent)" : "var(--faint)",
                opacity: cert.active ? 1 : 0.75,
              }}
            >
              {cert.active ? <Check size={9} /> : <span className="h-1 w-1 rounded-full" style={{ background: "var(--faint)" }} />}
              {cert.label}
            </span>
          ))}
        </div>
        <div className="mt-2.5 flex items-center gap-1.5 border-t pt-2 text-[9px]" style={{ borderColor: "var(--line)", color: "var(--faint)" }}>
          <MapPin size={10} /> {fmtTonnes(stats.volume)} of verified lots tracked across Karnataka
        </div>
      </div>
    </div>
  );
}
