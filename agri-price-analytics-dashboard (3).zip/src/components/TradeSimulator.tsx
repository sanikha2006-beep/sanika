import { useState, type FormEvent } from "react";
import { ArrowLeftRight, CheckCircle2, RotateCcw, Sparkles, TrendingUp } from "lucide-react";
import {
  COMMODITIES,
  CONTRACTS,
  PRACTICES,
  REGIONS,
  findBestMatch,
  fmtINR,
  fmtTime,
  fmtTonnes,
  getCommodity,
  getRegion,
  type BuyerBid,
  type ContractType,
  type FarmerOffer,
  type Practice,
} from "../lib/data";
import { LabeledField, SectionHead } from "./ui";

type LogTone = "farmer" | "buyer" | "match" | "system";

interface LogEntry {
  id: string;
  tone: LogTone;
  message: string;
  detail?: string;
  time: string;
}

const TONE_COLOR: Record<LogTone, string> = {
  farmer: "var(--accent)",
  buyer: "var(--sky)",
  match: "var(--lime)",
  system: "var(--faint)",
};

export default function TradeSimulator({
  offers,
  bids,
  onAddOffer,
  onAddBid,
  onReset,
}: {
  offers: FarmerOffer[];
  bids: BuyerBid[];
  onAddOffer: (offer: FarmerOffer) => void;
  onAddBid: (bid: BuyerBid) => void;
  onReset: () => void;
}) {
  const [offerForm, setOfferForm] = useState({
    commodityId: "paddy",
    regionId: "mandya",
    price: "",
    quantity: "",
    practice: "organic" as Practice,
  });
  const [bidForm, setBidForm] = useState({
    commodityId: "ragi",
    regionId: "bengaluru-urban",
    price: "",
    quantity: "",
    contract: "spot" as ContractType,
  });
  const [offerError, setOfferError] = useState("");
  const [bidError, setBidError] = useState("");
  const [log, setLog] = useState<LogEntry[]>([
    {
      id: "seed",
      tone: "system",
      message: "Live matching engine ready.",
      detail: "Best-match engine ranks open lots by spread × matched volume.",
      time: fmtTime(new Date()),
    },
  ]);

  function pushLog(entry: Omit<LogEntry, "id" | "time">) {
    setLog((current) =>
      [{ ...entry, id: `${Date.now()}-${Math.random()}`, time: fmtTime(new Date()) }, ...current].slice(0, 6)
    );
  }

  function submitOffer(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const price = Number.parseFloat(offerForm.price);
    const quantity = Number.parseFloat(offerForm.quantity);
    if (!Number.isFinite(price) || price <= 0) {
      setOfferError("Enter an ask price above zero (₹/quintal).");
      return;
    }
    if (!Number.isFinite(quantity) || quantity <= 0) {
      setOfferError("Enter the lot quantity in tonnes.");
      return;
    }
    const commodity = getCommodity(offerForm.commodityId);
    const region = getRegion(offerForm.regionId);
    const newOffer: FarmerOffer = {
      id: `F-manual-${Date.now()}`,
      commodityId: offerForm.commodityId as FarmerOffer["commodityId"],
      regionId: offerForm.regionId,
      price: Math.round(price),
      quantity,
      practice: offerForm.practice,
    };
    onAddOffer(newOffer);
    const match = findBestMatch([...offers, newOffer], bids);
    pushLog({
      tone: "farmer",
      message: `New farmer offer · ${commodity?.short} at ${fmtINR(newOffer.price)}/qtl`,
      detail: `${fmtTonnes(quantity)} from ${region?.district} · ${PRACTICES.find((p) => p.id === offerForm.practice)?.label}${
        match
          ? ` · Best bid ${fmtINR(match.bid.price)}/qtl · potential ${fmtINR(match.value)} trade`
          : " · awaiting an institutional bid"
      }`,
    });
    setOfferError("");
    setOfferForm((f) => ({ ...f, price: "", quantity: "" }));
  }

  function submitBid(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const price = Number.parseFloat(bidForm.price);
    const quantity = Number.parseFloat(bidForm.quantity);
    if (!Number.isFinite(price) || price <= 0) {
      setBidError("Enter a bid price above zero (₹/quintal).");
      return;
    }
    if (!Number.isFinite(quantity) || quantity <= 0) {
      setBidError("Enter the required quantity in tonnes.");
      return;
    }
    const commodity = getCommodity(bidForm.commodityId);
    const region = getRegion(bidForm.regionId);
    const newBid: BuyerBid = {
      id: `B-manual-${Date.now()}`,
      commodityId: bidForm.commodityId as BuyerBid["commodityId"],
      regionId: bidForm.regionId,
      price: Math.round(price),
      quantity,
      contract: bidForm.contract,
    };
    onAddBid(newBid);
    const match = findBestMatch(offers, [...bids, newBid]);
    pushLog({
      tone: "buyer",
      message: `New buyer bid · ${commodity?.short} at ${fmtINR(newBid.price)}/qtl`,
      detail: `${fmtTonnes(quantity)} to ${region?.district} · ${CONTRACTS.find((c) => c.id === bidForm.contract)?.label}${
        match
          ? ` · Best ask ${fmtINR(match.offer.price)}/qtl · potential ${fmtINR(match.value)} trade`
          : " · no matching farmer ask yet"
      }`,
    });
    setBidError("");
    setBidForm((f) => ({ ...f, price: "", quantity: "" }));
  }

  function resetAll() {
    onReset();
    setOfferError("");
    setBidError("");
    setOfferForm({ commodityId: "paddy", regionId: "mandya", price: "", quantity: "", practice: "organic" });
    setBidForm({ commodityId: "ragi", regionId: "bengaluru-urban", price: "", quantity: "", contract: "spot" });
    setLog([
      {
        id: `reset-${Date.now()}`,
        tone: "match",
        message: "Demo data reset.",
        detail: "Order book restored to Karnataka reference ranges.",
        time: fmtTime(new Date()),
      },
    ]);
  }

  return (
    <section id="simulate" className="surface p-4 sm:p-5">
      <SectionHead
        icon={<ArrowLeftRight size={15} />}
        title="Simulate a Karnataka trade match"
        subtitle="Add a farmer offer or a buyer bid, then watch the order book and analytics react instantly."
        actions={
          <button type="button" onClick={resetAll} className="btn-ghost text-[11px]">
            <RotateCcw size={12} /> Reset demo data
          </button>
        }
        compact
      />

      <div className="mt-3.5 grid gap-3 lg:grid-cols-[1.05fr_1.05fr_0.9fr]">
        <form onSubmit={submitOffer} className="surface-soft flex flex-col gap-2 p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 text-[11.5px] font-semibold">
              <TrendingUp size={12} style={{ color: "var(--accent)" }} /> New farmer offer
            </span>
            <span className="rounded-full px-2 py-0.5 text-[8.5px] font-medium" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
              Farmgate / FPO
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <LabeledField label="Commodity">
              <select
                value={offerForm.commodityId}
                onChange={(e) => setOfferForm((f) => ({ ...f, commodityId: e.target.value }))}
                className="field py-1.5"
              >
                {COMMODITIES.map((c) => <option key={c.id} value={c.id}>{c.short}</option>)}
              </select>
            </LabeledField>
            <LabeledField label="District / mandi">
              <select
                value={offerForm.regionId}
                onChange={(e) => setOfferForm((f) => ({ ...f, regionId: e.target.value }))}
                className="field py-1.5"
              >
                {REGIONS.map((r) => <option key={r.id} value={r.id}>{r.district}</option>)}
              </select>
            </LabeledField>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <LabeledField label="Ask ₹/qtl">
              <input
                type="number"
                min="1"
                step="1"
                value={offerForm.price}
                onChange={(e) => setOfferForm((f) => ({ ...f, price: e.target.value }))}
                placeholder={String(getCommodity(offerForm.commodityId)?.baseline)}
                className="field py-1.5 tabular"
              />
            </LabeledField>
            <LabeledField label="Qty (t)">
              <input
                type="number"
                min="0.1"
                step="0.1"
                value={offerForm.quantity}
                onChange={(e) => setOfferForm((f) => ({ ...f, quantity: e.target.value }))}
                placeholder="5.0"
                className="field py-1.5 tabular"
              />
            </LabeledField>
            <LabeledField label="Practice">
              <select
                value={offerForm.practice}
                onChange={(e) => setOfferForm((f) => ({ ...f, practice: e.target.value as Practice }))}
                className="field py-1.5"
              >
                {PRACTICES.map((p) => <option key={p.id} value={p.id}>{p.short}</option>)}
              </select>
            </LabeledField>
          </div>
          {offerError && <p className="text-[10px]" style={{ color: "#e2694f" }}>{offerError}</p>}
          <button type="submit" className="btn-primary mt-auto w-full py-2">
            <Sparkles size={12} /> Add farmer offer
          </button>
        </form>

        <form onSubmit={submitBid} className="surface-soft flex flex-col gap-2 p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 text-[11.5px] font-semibold">
              <TrendingUp size={12} style={{ color: "var(--sky)" }} /> New buyer bid
            </span>
            <span className="rounded-full px-2 py-0.5 text-[8.5px] font-medium" style={{ background: "rgba(26,127,168,0.1)", color: "var(--sky)" }}>
              Institutional
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <LabeledField label="Commodity">
              <select
                value={bidForm.commodityId}
                onChange={(e) => setBidForm((f) => ({ ...f, commodityId: e.target.value }))}
                className="field py-1.5"
              >
                {COMMODITIES.map((c) => <option key={c.id} value={c.id}>{c.short}</option>)}
              </select>
            </LabeledField>
            <LabeledField label="Delivery region">
              <select
                value={bidForm.regionId}
                onChange={(e) => setBidForm((f) => ({ ...f, regionId: e.target.value }))}
                className="field py-1.5"
              >
                {REGIONS.map((r) => <option key={r.id} value={r.id}>{r.district}</option>)}
              </select>
            </LabeledField>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <LabeledField label="Bid ₹/qtl">
              <input
                type="number"
                min="1"
                step="1"
                value={bidForm.price}
                onChange={(e) => setBidForm((f) => ({ ...f, price: e.target.value }))}
                placeholder={String(Math.round((getCommodity(bidForm.commodityId)?.baseline ?? 1000) * 1.08))}
                className="field py-1.5 tabular"
              />
            </LabeledField>
            <LabeledField label="Qty (t)">
              <input
                type="number"
                min="0.1"
                step="0.1"
                value={bidForm.quantity}
                onChange={(e) => setBidForm((f) => ({ ...f, quantity: e.target.value }))}
                placeholder="8.0"
                className="field py-1.5 tabular"
              />
            </LabeledField>
            <LabeledField label="Contract">
              <select
                value={bidForm.contract}
                onChange={(e) => setBidForm((f) => ({ ...f, contract: e.target.value as ContractType }))}
                className="field py-1.5"
              >
                {CONTRACTS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
              </select>
            </LabeledField>
          </div>
          {bidError && <p className="text-[10px]" style={{ color: "#e2694f" }}>{bidError}</p>}
          <button type="submit" className="btn-subtle mt-auto w-full py-2">
            <CheckCircle2 size={12} /> Add buyer bid
          </button>
        </form>

        <div className="surface-soft flex flex-col p-3" aria-live="polite">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11.5px] font-semibold">Match outcome</span>
            <span className="font-mono text-[8.5px] uppercase tracking-wide" style={{ color: "var(--faint)" }}>Simulated</span>
          </div>
          <div className="scroll-thin mt-2 flex max-h-[220px] flex-1 flex-col gap-2 overflow-y-auto pr-1">
            {log.map((entry) => (
              <div key={entry.id} className="flex gap-2">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: TONE_COLOR[entry.tone] }} />
                <div className="min-w-0">
                  <p className="text-[10px] font-medium leading-snug">{entry.message}</p>
                  {entry.detail && (
                    <p className="mt-0.5 text-[9px] leading-snug" style={{ color: "var(--faint)" }}>{entry.detail}</p>
                  )}
                  <span className="mt-0.5 block font-mono text-[8.5px]" style={{ color: "var(--faint)" }}>{entry.time}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-2 border-t pt-2 text-[9px] leading-relaxed" style={{ borderColor: "var(--line)", color: "var(--faint)" }}>
            Open lots are ranked by price spread × matched volume. All trades are simulated for demonstration.
          </div>
        </div>
      </div>
    </section>
  );
}
