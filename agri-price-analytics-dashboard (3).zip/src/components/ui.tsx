import type { ReactNode } from "react";
import { Leaf, Moon, Sun } from "lucide-react";
import { cn } from "../utils/cn";
import { getCommodity, type CommodityId } from "../lib/data";

export function Logo({
  size = "md",
  inverted = false,
}: {
  size?: "sm" | "md" | "lg";
  inverted?: boolean;
}) {
  const dims = size === "lg" ? "h-12 w-12 rounded-[15px]" : size === "sm" ? "h-8 w-8 rounded-[10px]" : "h-10 w-10 rounded-xl";
  const icon = size === "lg" ? 26 : size === "sm" ? 17 : 21;
  const title = size === "lg" ? "text-[22px]" : size === "sm" ? "text-[15px]" : "text-[17px]";
  return (
    <div className="flex items-center gap-2.5">
      <div
        className={cn("relative flex shrink-0 items-center justify-center shadow-lg", dims)}
        style={{
          background: "linear-gradient(150deg, var(--accent-bright) 0%, var(--accent) 48%, var(--lime) 130%)",
          color: "var(--accent-ink)",
          boxShadow: "0 8px 22px -12px var(--accent)",
        }}
      >
        <Leaf size={icon} strokeWidth={2.2} />
        <span
          className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full border-2"
          style={{ background: "var(--lime)", borderColor: "var(--panel)" }}
        />
      </div>
      <div className="leading-none">
        <div className={cn("font-display font-semibold tracking-tight", title)} style={{ color: inverted ? "#f3fbf6" : "var(--text)" }}>
          GreenLink
        </div>
        <div
          className={cn("mt-1 font-medium uppercase tracking-[0.2em]", size === "lg" ? "text-[10.5px]" : "text-[9px]")}
          style={{ color: inverted ? "rgba(226,245,234,0.7)" : "var(--faint)" }}
        >
          Karnataka
        </div>
      </div>
    </div>
  );
}

export function ThemeToggle({
  theme,
  onToggle,
  className,
}: {
  theme: "dark" | "light";
  onToggle: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      className={cn(
        "group inline-flex h-9 items-center gap-2 rounded-full border px-2.5 text-[11px] font-medium transition",
        className
      )}
      style={{ borderColor: "var(--line-strong)", color: "var(--muted)", background: "var(--panel-2)" }}
    >
      {theme === "dark" ? <Moon size={14} /> : <Sun size={14} />}
      <span className="hidden sm:inline">{theme === "dark" ? "Dark" : "Light"}</span>
      <span className="relative h-4 w-7 rounded-full transition" style={{ background: theme === "dark" ? "var(--accent-soft)" : "var(--panel-3)" }}>
        <span
          className="absolute top-0.5 h-3 w-3 rounded-full transition-all"
          style={{
            background: "var(--accent)",
            left: theme === "dark" ? "2px" : "12px",
          }}
        />
      </span>
    </button>
  );
}

export function SectionHead({
  icon,
  title,
  subtitle,
  actions,
  compact = false,
}: {
  icon?: ReactNode;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  compact?: boolean;
}) {
  return (
    <div className={cn("flex flex-wrap items-start justify-between gap-3", compact ? "mb-0" : "mb-4")}>
      <div className="flex min-w-0 items-start gap-3">
        {icon && (
          <div
            className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px]"
            style={{ background: "var(--accent-soft)", color: "var(--accent)", border: "1px solid var(--accent-line)" }}
          >
            {icon}
          </div>
        )}
        <div className="min-w-0">
          <h3 className="font-display text-[13.5px] font-semibold leading-tight">{title}</h3>
          {subtitle && <p className="mt-1 text-[11px] leading-relaxed" style={{ color: "var(--muted)" }}>{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function LabeledField({
  label,
  hint,
  children,
  className,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("flex min-w-0 flex-col gap-1.5", className)}>
      <span className="flex items-baseline justify-between gap-2">
        <span className="text-[10.5px] font-medium uppercase tracking-[0.09em]" style={{ color: "var(--muted)" }}>
          {label}
        </span>
        {hint && <span className="text-[10px]" style={{ color: "var(--faint)" }}>{hint}</span>}
      </span>
      {children}
    </label>
  );
}

export function ProgressRow({
  label,
  value,
  percent,
  tone = "emerald",
  caption,
}: {
  label: string;
  value: string;
  percent: number;
  tone?: "emerald" | "sky" | "lime" | "amber";
  caption?: string;
}) {
  const gradients: Record<string, string> = {
    emerald: "linear-gradient(90deg, var(--accent), var(--lime))",
    sky: "linear-gradient(90deg, var(--sky), var(--accent))",
    lime: "linear-gradient(90deg, var(--lime), var(--accent-bright))",
    amber: "linear-gradient(90deg, var(--amber), var(--lime))",
  };
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-[11px]" style={{ color: "var(--muted)" }}>{label}</span>
        <span className="font-mono text-[11.5px] font-semibold" style={{ color: "var(--accent)" }}>{value}</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--panel-3)" }}>
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{ width: `${Math.max(2, Math.min(100, percent))}%`, background: gradients[tone] }}
        />
      </div>
      {caption && <p className="text-[10.5px] leading-relaxed" style={{ color: "var(--faint)" }}>{caption}</p>}
    </div>
  );
}

const COMMODITY_COLORS: Record<CommodityId, string> = {
  paddy: "#d9a441",
  ragi: "#6fae43",
  tur: "#bf8a45",
  groundnut: "#c98b50",
  tomato: "#d9634a",
  onion: "#9a6bb5",
};

export function CommodityMark({ id, size = 26 }: { id: string; size?: number }) {
  const commodity = getCommodity(id);
  const color = COMMODITY_COLORS[(commodity?.id ?? "paddy") as CommodityId];
  return (
    <span
      className="inline-flex shrink-0 items-center justify-center rounded-[8px] font-mono font-semibold"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.34,
        color,
        background: `${color}1f`,
        border: `1px solid ${color}3d`,
      }}
    >
      {commodity?.code ?? "GL"}
    </span>
  );
}

export function LiveBadge({ live }: { live: boolean }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.09em]"
      style={{
        borderColor: live ? "var(--accent-line)" : "var(--line-strong)",
        background: live ? "var(--accent-soft)" : "var(--panel-2)",
        color: live ? "var(--accent)" : "var(--muted)",
      }}
    >
      <span
        className={cn("h-1.5 w-1.5 rounded-full", live && "live-dot")}
        style={{ background: live ? "var(--accent)" : "var(--faint)" }}
      />
      {live ? "Live price feed" : "Feed paused"}
    </span>
  );
}

export function EmptyState({ children }: { children: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-1 px-4 py-10 text-center">
      <Leaf size={18} style={{ color: "var(--faint)" }} />
      <p className="text-[11px]" style={{ color: "var(--faint)" }}>{children}</p>
    </div>
  );
}
