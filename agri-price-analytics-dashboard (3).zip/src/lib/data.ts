export type CommodityId = "paddy" | "ragi" | "tur" | "groundnut" | "tomato" | "onion";
export type Practice = "organic" | "rainfed" | "regenerative" | "conventional";
export type ContractType = "spot" | "weekly" | "seasonal";

export interface Commodity {
  id: CommodityId;
  name: string;
  short: string;
  code: string;
  unit: string;
  baseline: number;
  benchmark: string;
  season: string;
}

export interface Region {
  id: string;
  district: string;
  market: string;
  label: string;
  zone: "South" | "North" | "Central";
  multiplier: number;
}

export interface FarmerOffer {
  id: string;
  commodityId: CommodityId;
  regionId: string;
  price: number;
  quantity: number;
  practice: Practice;
}

export interface BuyerBid {
  id: string;
  commodityId: CommodityId;
  regionId: string;
  price: number;
  quantity: number;
  contract: ContractType;
}

export interface MarketSnapshot {
  commodity: Commodity;
  minAsk: number;
  maxBid: number;
  mid: number;
  spread: number;
  volume: number;
  depth: number;
  vsBenchmark: number;
  offers: number;
  bids: number;
}

export const COMMODITIES: Commodity[] = [
  {
    id: "paddy",
    name: "Paddy (Kharif)",
    short: "Paddy",
    code: "PD",
    unit: "quintal",
    baseline: 2200,
    benchmark: "MSP reference",
    season: "Kharif",
  },
  {
    id: "ragi",
    name: "Ragi / Finger Millet",
    short: "Ragi",
    code: "RG",
    unit: "quintal",
    baseline: 3400,
    benchmark: "MSP reference",
    season: "Kharif",
  },
  {
    id: "tur",
    name: "Tur / Pigeon Pea",
    short: "Tur",
    code: "TR",
    unit: "quintal",
    baseline: 6500,
    benchmark: "MSP reference",
    season: "Kharif",
  },
  {
    id: "groundnut",
    name: "Groundnut (in shell)",
    short: "Groundnut",
    code: "GN",
    unit: "quintal",
    baseline: 6200,
    benchmark: "MSP reference",
    season: "Kharif",
  },
  {
    id: "tomato",
    name: "Tomato (fresh)",
    short: "Tomato",
    code: "TM",
    unit: "quintal",
    baseline: 900,
    benchmark: "Mandi benchmark",
    season: "Rabi / perennial",
  },
  {
    id: "onion",
    name: "Onion (red)",
    short: "Onion",
    code: "ON",
    unit: "quintal",
    baseline: 1300,
    benchmark: "Mandi benchmark",
    season: "Rabi",
  },
];

export const REGIONS: Region[] = [
  { id: "bengaluru-rural", district: "Bengaluru Rural", market: "Hoskote APMC", label: "Bengaluru Rural · Hoskote APMC", zone: "South", multiplier: 1.05 },
  { id: "bengaluru-urban", district: "Bengaluru Urban", market: "Yeshwanthpur APMC", label: "Bengaluru Urban · Yeshwanthpur APMC", zone: "South", multiplier: 1.08 },
  { id: "mandya", district: "Mandya", market: "Mandya APMC", label: "Mandya · Mandya APMC", zone: "South", multiplier: 1 },
  { id: "mysuru", district: "Mysuru", market: "Mysuru APMC", label: "Mysuru · Mysuru APMC", zone: "South", multiplier: 1.02 },
  { id: "belagavi", district: "Belagavi", market: "Belagavi APMC", label: "Belagavi · Belagavi APMC", zone: "North", multiplier: 0.97 },
  { id: "ballari", district: "Ballari", market: "Ballari APMC", label: "Ballari · Ballari APMC", zone: "North", multiplier: 0.95 },
  { id: "raichur", district: "Raichur", market: "Raichur APMC", label: "Raichur · Raichur APMC", zone: "North", multiplier: 0.93 },
  { id: "hubballi", district: "Hubballi", market: "Hubballi APMC", label: "Hubballi · Hubballi APMC", zone: "North", multiplier: 0.99 },
  { id: "chitradurga", district: "Chitradurga", market: "Chitradurga APMC", label: "Chitradurga · Chitradurga APMC", zone: "Central", multiplier: 0.96 },
];

export const PRACTICES: { id: Practice; label: string; short: string }[] = [
  { id: "organic", label: "Certified Organic", short: "Organic" },
  { id: "rainfed", label: "Rain-fed", short: "Rain-fed" },
  { id: "regenerative", label: "Regenerative", short: "Regenerative" },
  { id: "conventional", label: "Conventional+", short: "Conventional+" },
];

export const CONTRACTS: { id: ContractType; label: string }[] = [
  { id: "spot", label: "Spot" },
  { id: "weekly", label: "Weekly" },
  { id: "seasonal", label: "Seasonal" },
];

export const getCommodity = (id: string) => COMMODITIES.find((c) => c.id === id);
export const getRegion = (id: string) => REGIONS.find((r) => r.id === id);
export const getPractice = (id: Practice) => PRACTICES.find((p) => p.id === id);

export function seededRandom(seed: number) {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

export function createDemoData(): { offers: FarmerOffer[]; bids: BuyerBid[] } {
  const offers: FarmerOffer[] = [];
  const bids: BuyerBid[] = [];
  let seed = 71;

  COMMODITIES.forEach((commodity, ci) => {
    REGIONS.forEach((region, ri) => {
      const rand = seededRandom(seed++);
      const practice = PRACTICES[(ci * 2 + ri) % PRACTICES.length].id;
      offers.push({
        id: `F-${commodity.id}-${region.id}`,
        commodityId: commodity.id,
        regionId: region.id,
        price: Math.round(commodity.baseline * region.multiplier * (0.945 + rand * 0.115)),
        quantity: Math.round((2.4 + rand * 8.2) * 10) / 10,
        practice,
      });

      const bidRand = seededRandom(seed++);
      const contract = CONTRACTS[(ci + ri) % CONTRACTS.length].id;
      bids.push({
        id: `B-${commodity.id}-${region.id}`,
        commodityId: commodity.id,
        regionId: region.id,
        price: Math.round(commodity.baseline * region.multiplier * (1.025 + bidRand * 0.135)),
        quantity: Math.round((3.1 + bidRand * 10.6) * 10) / 10,
        contract,
      });
    });
  });

  return { offers, bids };
}

export function jitterMarket(
  offers: FarmerOffer[],
  bids: BuyerBid[],
  factor = 0.018
): { offers: FarmerOffer[]; bids: BuyerBid[] } {
  const move = () => 1 + (Math.random() > 0.5 ? 1 : -1) * Math.random() * factor;
  return {
    offers: offers.map((o) => ({ ...o, price: Math.max(1, Math.round(o.price * move())) })),
    bids: bids.map((b) => ({ ...b, price: Math.max(1, Math.round(b.price * move())) })),
  };
}

export function snapshotFor(
  commodityId: string,
  offers: FarmerOffer[],
  bids: BuyerBid[]
): MarketSnapshot | null {
  const commodity = getCommodity(commodityId) ?? COMMODITIES[0];
  const offs = offers.filter((o) => o.commodityId === commodityId);
  const bs = bids.filter((b) => b.commodityId === commodityId);
  if (!offs.length || !bs.length) return null;
  const minAsk = Math.min(...offs.map((o) => o.price));
  const maxBid = Math.max(...bs.map((b) => b.price));
  const mid = Math.round((minAsk + maxBid) / 2);
  const volume = [...offs, ...bs].reduce((sum, lot) => sum + lot.quantity, 0);
  return {
    commodity,
    minAsk,
    maxBid,
    mid,
    spread: Math.max(0, maxBid - minAsk),
    volume,
    depth: Math.min(99, Math.round(volume * 0.62)),
    vsBenchmark: ((mid - commodity.baseline) / commodity.baseline) * 100,
    offers: offs.length,
    bids: bs.length,
  };
}

export interface MatchResult {
  offer: FarmerOffer;
  bid: BuyerBid;
  spread: number;
  quantity: number;
  score: number;
  value: number;
}

export function findBestMatch(offers: FarmerOffer[], bids: BuyerBid[]): MatchResult | null {
  let best: MatchResult | null = null;
  for (const offer of offers) {
    for (const bid of bids) {
      if (offer.commodityId !== bid.commodityId) continue;
      const spread = bid.price - offer.price;
      if (spread < 0) continue;
      const quantity = Math.min(offer.quantity, bid.quantity);
      const score = spread * quantity;
      if (!best || score > best.score) {
        best = {
          offer,
          bid,
          spread,
          quantity,
          score,
          value: Math.round(((offer.price + bid.price) / 2) * quantity * 10),
        };
      }
    }
  }
  return best;
}

export const fmtINR = (value: number, fractionDigits = 0) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: fractionDigits,
    minimumFractionDigits: fractionDigits,
  }).format(value);

export const fmtNumber = (value: number, fractionDigits = 0) =>
  new Intl.NumberFormat("en-IN", {
    maximumFractionDigits: fractionDigits,
    minimumFractionDigits: fractionDigits,
  }).format(value);

export const fmtTonnes = (value: number) => `${value.toFixed(1)} t`;

export const fmtTime = (date: Date) =>
  date.toLocaleTimeString("en-IN", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
