import JSZip from "jszip";

const README = `GREENLINK KARNATAKA — OFFLINE WEBSITE COPY
==========================================

HOW TO OPEN ON WINDOWS
1. Right-click this downloaded ZIP and choose "Extract All...".
2. Open the extracted folder (it is called GreenLink-Karnataka).
3. Double-click "index.html". It opens in your web browser.

HOW TO OPEN ON macOS
1. Double-click the ZIP to extract it.
2. Open the GreenLink-Karnataka folder.
3. Double-click "index.html".

HOW TO OPEN ON A CHROMEBOOK
1. Open the Files app and extract the ZIP.
2. Select index.html and choose "Open with Google Chrome".

IMPORTANT — IF YOU SEE A BLANK PAGE
- Do NOT open index.html from inside the ZIP preview window. Extract the ZIP first, then open the extracted file.
- Do NOT double-click the index.html in the original project/source folder. That is the developer entry file and needs a build step.
- If double-clicking opens a text editor, right-click index.html > "Open with" > Chrome / Edge / Firefox / Safari.
- The website is a single self-contained file: all styles, scripts and images are inside index.html.

SIGNING IN
- Demo email: demo@greenlink.in
- Demo password: greenlink123
- Or press "Explore with demo credentials" on the sign-in screen.

GOOD TO KNOW
- No installation or local server is required.
- No internet connection is required. If you are online, the Google Fonts webfont loads; if you are offline, the page automatically uses system fonts.
- Prices and trades in this concept dashboard are simulated. Nothing is sent to a server.
- Toggle dark / light mode with the theme button in the top-right corner.
- You can export the live order book as a CSV with the "Export book" button.

CONTENTS
- index.html  — the complete standalone website
- README.txt  — this file

GreenLink Karnataka · Concept workspace · 2026
`;

const SOURCE_NOTE = `GreenLink Karnataka — Source project
====================================

This copy is intended for developers and requires Node.js 18+.

QUICK START
1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run: npm install
4. Run: npm run dev
5. Open the local URL printed in the terminal (usually http://localhost:5173).

PRODUCTION BUILD
1. Run: npm run build
2. Open dist/index.html in your browser. All assets are inlined into that single file.

IMPORTANT
- The index.html at the TOP LEVEL of this folder is the Vite entry file. Opening it directly by double-clicking will show a blank page or a help notice. It only works through the dev server.
- For a ready-to-open website, use dist/index.html or the separate standalone website download.

Demo email: demo@greenlink.in
Demo password: greenlink123
`;

function isUsableDocument(text: string) {
  return (
    text.includes("<html") &&
    text.includes('id="root"') &&
    text.includes("<script") &&
    text.length > 20000
  );
}

async function snapshotHtml(): Promise<string> {
  // Preferred: download the original, already self-contained document that the
  // server delivered. This avoids saving transient UI state (open dialogs etc.).
  if (typeof window !== "undefined" && window.location.protocol.startsWith("http")) {
    try {
      const response = await fetch(window.location.href, { cache: "no-store" });
      if (response.ok) {
        const text = await response.text();
        if (isUsableDocument(text)) return text;
      }
    } catch {
      /* fall through to the DOM snapshot */
    }
  }

  const body = document.body;
  const previousOverflow = body.style.overflow;
  const previousPadding = body.style.paddingRight;
  // Release any scroll lock applied by an open dialog so the saved copy scrolls normally.
  body.style.overflow = "";
  body.style.paddingRight = "";

  const html = `<!doctype html>\n${document.documentElement.outerHTML}`;

  body.style.overflow = previousOverflow;
  body.style.paddingRight = previousPadding;
  return html;
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function downloadStandaloneHtml(): Promise<void> {
  const html = await snapshotHtml();
  triggerDownload(new Blob([html], { type: "text/html;charset=utf-8" }), "GreenLink-Karnataka.html");
}

export async function downloadWebsiteZip(): Promise<void> {
  const zip = new JSZip();
  const folder = zip.folder("GreenLink-Karnataka");
  if (!folder) throw new Error("Could not create ZIP folder.");
  folder.file("index.html", await snapshotHtml());
  folder.file("README.txt", README);
  folder.file("SOURCE-INSTRUCTIONS.txt", SOURCE_NOTE);
  const blob = await zip.generateAsync({
    type: "blob",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });
  triggerDownload(blob, "GreenLink-Karnataka-website.zip");
}
