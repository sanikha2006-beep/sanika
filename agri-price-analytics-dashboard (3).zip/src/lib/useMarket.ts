import { useCallback, useEffect, useMemo, useState } from "react";
import {
  createDemoData,
  jitterMarket,
  type BuyerBid,
  type FarmerOffer,
} from "./data";

export function useMarket() {
  const [data, setData] = useState(() => createDemoData());
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(() => new Date());
  const [tick, setTick] = useState(0);

  const refresh = useCallback(() => {
    setData((current) => jitterMarket(current.offers, current.bids));
    setLastUpdated(new Date());
    setTick((t) => t + 1);
  }, []);

  useEffect(() => {
    if (!autoRefresh) return;
    const id = window.setInterval(refresh, 7000);
    return () => window.clearInterval(id);
  }, [autoRefresh, refresh]);

  const addOffer = useCallback((offer: FarmerOffer) => {
    setData((current) => ({ ...current, offers: [...current.offers, offer] }));
    setLastUpdated(new Date());
    setTick((t) => t + 1);
  }, []);

  const addBid = useCallback((bid: BuyerBid) => {
    setData((current) => ({ ...current, bids: [...current.bids, bid] }));
    setLastUpdated(new Date());
    setTick((t) => t + 1);
  }, []);

  const reset = useCallback(() => {
    setData(createDemoData());
    setLastUpdated(new Date());
    setTick((t) => t + 1);
  }, []);

  const totals = useMemo(() => {
    const totalVolume = [...data.offers, ...data.bids].reduce((sum, lot) => sum + lot.quantity, 0);
    const carbonSaved = 18 + totalVolume * 0.047;
    const ordersChange = 3.8 + (tick % 5) * 0.2;
    return { totalVolume, carbonSaved, ordersChange };
  }, [data, tick]);

  return {
    offers: data.offers,
    bids: data.bids,
    autoRefresh,
    setAutoRefresh,
    lastUpdated,
    tick,
    refresh,
    addOffer,
    addBid,
    reset,
    totals,
  };
}
